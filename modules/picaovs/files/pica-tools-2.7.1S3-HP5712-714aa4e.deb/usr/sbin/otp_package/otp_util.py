#!/usr/bin/env python2.7

# Copyright (c) 2009-2014 Pica8, Inc.
# http://pica8.org


# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License, Version
# 2.1, June 1999 as published by the Free Software Foundation.
# Redistribution and/or modification of this program under the terms of
# any other version of the GNU Lesser General Public License is not
# permitted.

# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. For more details,
# see the GNU Lesser General Public License, Version 2.1, a copy of
# which can be found in the LICENSE file.

import base64
import getpass
import hashlib
import os
import pexpect
import pxssh
import re
import sys
import subprocess
import select
from pexpect import *

def get_residual_jobs_file_name():
    return "/cftmp/otp_residual_jobs"

def register_residual_job(cmd):
    """
    Each line in this file is a linux command, likes:
    python /cftmp/linux_configuration.py
    """
    cmd = "echo %s >> %s" % (cmd, get_residual_jobs_file_name())
    ok = subprocess.call(cmd, shell=True)
    register_clean_file(get_residual_jobs_file_name())
    if ok == 0:
        return True
    else:
        return False

def do_residual_jobs():
    file_name = get_residual_jobs_file_name()
    if os.path.exists(file_name) == False:
        return
    infile = open(file_name)
    for line in infile:
        res = subprocess.call(line,
                              shell=True,
                              stderr=open('/dev/null', 'w'))
    infile.close()

def get_clean_file_name():
    return "/cftmp/otp_clean_list"

def register_clean_file(fname):
    """
    Each line in this file likes:
    b67d67a4e82df92e49ef83e34a2dc82d  provision.py
    946ceef2410da3e2b88b401a803342b5  linux_configure.py
    """
    cmd = "md5sum %s >> %s" % (fname, get_clean_file_name())
    ok = subprocess.call(cmd, shell=True)
    if ok == 0:
        return True
    else:
        return False

def do_clean():
    file_name = get_clean_file_name()
    if os.path.exists(file_name) == False:
        return
    infile = open(file_name)
    for line in infile:
        value = line.split()
        if len(value) != 2:
            continue
        if os.path.exists(value[1]) == False:
            continue
        res = subprocess.check_output("md5sum %s" % value[1], shell=True)
        if res == line:
            os.remove(value[1])
    infile.close()
    os.remove(get_clean_file_name())
    subprocess.call("sync", shell=True)

def validate_ip(ip):
    """Validate a dotted-quad ip address.

    The string is considered a valid dotted-quad address if it consists of
    one to four octets (0-255) seperated by periods (.).

    >>> validate_ip('127.0.0.1')
    True
    >>> validate_ip('127.0')
    True
    >>> validate_ip('127.0.0.256')
    False
    """
    r = (r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.)"
         r"{3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$")
    if re.compile(r).match(ip):
        quads = ip.split('.')
        for q in quads:
            if int(q) > 255:
                return False
        return True
    return False

def validate_cidr(cidr_ip):
    """Validate a CIDR notation ip address.

    The string is considered a valid CIDR address if it consists of a valid
    IPv4 address in dotted-quad format followed by a forward slash (/) and
    a bit mask length (1-32).

    >>> validate_cidr('127.0.0.1/32')
    True
    >>> validate_cidr('127.0/8')
    True
    >>> validate_cidr('127.0.0.256/32')
    False
    >>> validate_cidr('127.0.0.0')
    False
    >>> validate_cidr('127.0.0.1/33')
    False
    """
    if re.compile(r'^(\d{1,3}\.){0,3}\d{1,3}/\d{1,2}$').match(cidr_ip):
        ip, mask = cidr_ip.split('/')
        if validate_ip(ip):
            if int(mask) > 32:
                return False
        else:
            return False
        return True
    return False

def is_ip_in_net(ip, net):
    """Validate whether ip address belongs to a net

    The ip string is a valid ip and net is a valid cidr address

    >>> is_ip_in_net('1,1,1,1', '1.1.1.1/24')
    True
    >>> is_ip_in_net('1,1,1,1', '1.1.1.0/24')
    True
    >>> is_ip_in_net('1,1,2,1', '1.1.1.1/24')
    False
    """
    ipaddr = int(''.join([ '%02x' % int(x) for x in ip.split('.') ]), 16)
    netstr, bits = net.split('/')
    netaddr = int(''.join([ '%02x' % int(x) for x in netstr.split('.') ]), 16)
    mask = (0xffffffff << (32 - int(bits))) & 0xffffffff
    return (ipaddr & mask) == (netaddr & mask)

def cidr_to_ipmaskstr(cidr):
    """CIDR address to ip string and mask string

    >>> cidr_to_ipmaskstr('1.1.1.1/24')
    ("1.1.1.1", "255.255.255.0")
    """
    (ip_str, mask_len_str) = cidr.split('/')
    mask_len_int = int(mask_len_str)

    bits = 0
    for i in xrange(32-mask_len_int, 32):
        bits |= (1 << i)
    mask_str = "%d.%d.%d.%d" % ((bits & 0xff000000) >> 24,
                                (bits & 0xff0000) >> 16,
                                (bits & 0xff00) >> 8,
                                (bits & 0xff))
    return (ip_str, mask_str)

def ask_timeout(prompt, default=None, format_checker=None,
                timeout=10, timeout_with_default=True):
    print prompt,
    sys.stdout.flush()
    i, _, _ = select.select([sys.stdin], [], [], timeout)
    if (i):
        return sys.stdin.readline().strip()
    else:
        if timeout_with_default == True:
            return default
        else:
            return None

def ask(prompt, default=None, format_checker=None, help_info=None):
    """Interfactive shell for raw_input

    Args:
        prompt: prompt string
        must_input: will loop forever if input nothing and must_input is set

    Returns:
        The input
    """
    while True:
        a = raw_input(prompt)
        if a == '' and default != None:
            return default
        if format_checker != None:
            if format_checker(a) == True:
                return a
            else:
                if help_info != None:
                    print help_info
                continue
        else:
            return a

def ask_ok_checker(a):
    """Check whether a valid answer for yes/no
    """
    valid_value = {'y', 'ye', 'yes', 'n', 'no', 'nop', 'nope'}
    if a in valid_value:
        return True
    else:
        return False

def ask_ok(prompt, default):
    """Interfactive shell for Yes/No

    Args:
        prompt: prompt string
        default: default answer if input nothing

    Returns:
        True: if input is y, ye, or yes
        False: if input is n, no, nop, nope
    """
    help_info = "Please inputs [y|ye|yes|n|no|nop|nope]."
    ok = ask(prompt, default, ask_ok_checker, help_info)
    if ok in('y', 'ye', 'yes'):
        return True
    if ok in('n', 'no', 'nop', 'nope'):
        return False

def ask_vlan_checker(a):
    if a.isdigit() == False:
        return False;
    vlan = int(a)
    if vlan < 1 or vlan >4096:
        return False
    else:
        return True

def ask_vlan(prompt, default):
    return ask(prompt, default, ask_vlan_checker)

def ask_speed_checker(a):
    if a in ('1G', '10G', '40G'):
        return True
    else:
        return False

def ask_speed(prompt, default=None):
    # help_info = "Please inputs [1G|10G|40G]."
    return ask(prompt, default, ask_speed_checker)

def ask_cidr_ip(prompt, default=None):
    """Ask for a ip address of CIDR format
    """
    return ask(prompt, default, validate_cidr)

def ask_ip(prompt, default=None):
    """Ask for a ip address of normal ip format
    """
    return ask(prompt, default, validate_ip)

def ask_passwd(prompt):
    """Ask for a passwd, which will not display the passwd when inputting
    """
    passwd = getpass.getpass(prompt)
    return passwd

def ask_passwd_twice(name):
    while True:
        q = "Enter password for(%s):" % name
        pass1 = ask_passwd(q)
        q = "Enter password for(%s) again:" % name
        pass2 = ask_passwd(q)
        if pass1 == pass2:
            return pass1

def ping_connectivity_test(remote):
    """Use ping to test the connectivity
    """
    # r = subprocess.call("ping -c 1 %s" % remote,
    #                     shell=True,
    #                     stdout=open('/dev/null', 'w'),
    #                     stderr=subprocess.STDOUT)
    r = subprocess.call("ping -c 1 %s" % remote,
                        shell=True)
    if r == 0:
        return True
    else:
        return False

def ssh_connectivity_test(remote, user, passwd):
    """Use ssh  to test the connectivity

    Args:
      remote: ip address of ssh server
      user: username to connect ssh server
      passwd: password of <user>

    Returns:
      True: successfully to connect to the server
      False: failed to connect to the server
    """
    try:
        s = pxssh.pxssh()
        s.login(remote, user, passwd)
        s.logout()
        return True
    except Exception, e:
        return False

def ssh_download_file(remote, user, passwd, r_path, l_path):
    """Download a file from remote

    Args:
      remote: ip address of ssh server
      user: username to connect ssh server
      passwd: password of <user>
      r_path: file's full path in ssh server
      l_path: where this file will stored locally

    Returns:
      True: If download successfully
      False: If download failed
    """

    #TODO(gene.ge): find a way to check error
    cmdline = "scp %s@%s:%s %s" % \
          (user, remote, r_path, l_path)
    scpp = pexpect.spawn(cmdline, timeout=None)
    # scpp.logfile = sys.stdout
    try:
        i = scpp.expect(['password:', 'continue connecting (yes/no)?'])
        if i == 0:
            pass
        elif i == 1:
            scpp.sendline('yes')
            scpp.expect('password:')
        scpp.sendline(passwd)
        scpp.expect(pexpect.EOF)
        print scpp.before.strip()
        scpp.close()
    except pexpect.EOF:
        scpp.close()
    subprocess.call("sync", shell=True)
    if os.path.exists(l_path):
        return True
    else:
        return False

def get_interface_ip(ifname):
    """Get ip address from a interface

    >>> get_interface_ip('eth0')
    '10.10.50.1'
    """
    s = socket.socket(socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,                           #SIOCGIFADDR
        struct.pack('256s', ifname[:15])
        )[20:24]))

def call_with_command_line(cmd):
    print cmd
    return subprocess.call(cmd, shell=True)

def call_ignore_error_msg(cmd):
    return subprocess.call(cmd,
                           shell=True,
                           stdout=open('/dev/null', 'w'),
                           stderr=subprocess.STDOUT)

def encode_password(user, password):
    return base64.b64encode(user + password)

def decode_password(user, enc):
    b64 = base64.b64decode(enc)
    password = b64[:len(user)]
    return password
