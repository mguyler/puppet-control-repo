from ap_dispatcher import ap_dispatcher, ovs, xorp

import time,os

#vs = {'app':'OVS', 'procs':[{'task':'ovsdb-server','check':'ovsdb-ser'},{'task':'ovs-vswitchd','check':'"worker process"'}]}
#orp = {'app':'XorPlus', 'procs':[{'task':'xorp_rtrmgr','check':'xorp_rtr'},{'task':'/pica/bin/pica_sh','check':'/pica_sh'}]}


def main():
    # create auto provisioning process
    ap = ap_dispatcher('/usr/lib/python2.7/dist-packages/pica8/')

    #check the status of partition two
    #if not ap.ap.check_status_partition_two():
    #    ap.ap.on_exit_normal_info('Partition 2 is not ready')
    #    return

    # check if any tasks
    ap.read_targets()
    #if ap.app_targets == [] and ap.app_inactive_targets == []:
    if ap.application_targets == []:
        return

    # wait for pica8 application to start
    apps = [ovs, xorp]
    pica = ap.ap

    #check the setting of picos server, if no start-up options then exit    
    #if not check_picos_status(pica):
    #    return
 
    #applications = check_apps(pica, apps)

    ap.save_targets()

    #if ap.application_targets == []:
    #    return
    
    '''
    cmds = ['pwd', 'cd /', 'ls', 'df', 'date']
    for cmd in cmds:
        r = pica.cmd(cmd)
    '''

    print('\n===== Pica8 configuration provisioning system =====\n')

    # do application configuration tasks
    ap.dispatch_app()

    print('\n===== Pica8 configuration provisioning complete =====\n')


def check_picos_status(pica):
    cmd = 'grep picos_start /etc/picos/picos_start.conf'
    res = pica.expect(cmd)
    if "xorpplus" not in res[1] and "ovs" not in res[1]:
            return False
    return True
   
# return names of running applications
def check_apps(pica, apps):
    prompt = ['root@XorPlus>', '\r\n.+@.+[#>:]', '\r.*@.*[#>:]', '\n.+@.+[#>:]', 'XorPlus[#>]']
    applications = []
    cmd = 'ps -ef | grep '
    wait_for_app = True
    
    while wait_for_app:
        print('\n----- Waiting for Pica8 application to start -----\n')
        for a in apps:
            for p in a['procs']:
                r = pica.expect(cmd + p['check'])
                if p['task'] not in r[1]:
                    break
                applications.append(a['app'])
                wait_for_app = False

        time.sleep(15)
        
    #print('\n----- Waiting for 120 more sconds -----\n')
    #time.sleep(120)
    if xorp['app'] in applications:
        while not os.path.isfile('/tmp/run/rtrmgr_ready') or not os.path.isfile('/tmp/run/sif_ready'):
            #print('\n----- Waiting for XorPlus Ready-----\n')
            time.sleep(10)
                
    return applications
        

def test_application():
    prompt = ['root@XorPlus>', '\r\n.+@.+[#>:]', '\r.*@.*[#>:]', '\n.+@.+[#>:]', 'XorPlus[#>]']
    #ap = ap_dispatcher().ap
    aprvsn = ap_dispatcher('/usr/lib/python2.7/dist-packages/pica8/')
    ap = aprvsn.ap
    application = 'None'
    wait_for_app = True
    print('\n===== Pica8 configuration provisioning system =====\n')
    while wait_for_app:
        print('\n----- Waiting for Pica8 application to start -----\n')
        cmd = 'ps -ef | grep ovsdb-server'
        r = ap.expect(cmd)
        print('\n      checking OVS      \n')
        if 'ovs_database' in r[1]:
            cmd = 'ps -ef | grep ovs-vswitchd'
            r = ap.expect(cmd)
            if 'pidfile' in r[1]:
                application = 'OVS'
                wait_for_app = False
                time.sleep(10)
                break
        cmd = 'ps -ef | grep _rtrmgr'
        r = ap.expect(cmd)
        print('\n      checking XorPlus      \n')
        if 'xorp_rtrmgr' in r[1]:
            cmd = 'ps -ef | grep pica_sh'
            r = ap.expect(cmd, prompt)
            if '/pica/bin/pica_sh' in r[1]:
                application = 'Xorplus'
                wait_for_app = False
        time.sleep(10)

    print '\n\n----- Pica8 configuration started: %s -----\n\n' % application
    #r = ap.cmd(['pwd', 'cd /', 'ls', 'df', 'date'])
    r = ap.cmd(['pwd', 'ls', 'df', 'date'])
    print('\n===== Pica8 configuration provisioning system =====\n')


def test_process(path = ''):
    ap = ap_dispatcher(path)
    ap.read_targets()
    print ' -----provision completed list ------- '
    ap.printdict(ap.provision_completed_targets)
    print ' -----configuration completed list ------- '
    ap.printdict(ap.config_completed_targets)
    print ' ----- active list ------- '
    ap.printdict(ap.active_targets)
    print ' ----- application configuration list ------- '
    ap.printdict(ap.app_targets)
    #ap.dispatch()
    ap.dispatch_app()
    print ' ----- provision completed list ------- '
    ap.printdict(ap.provision_completed_targets)
    print ' ----- configuration completed list ------- '
    ap.printdict(ap.config_completed_targets)
    print ' ----- active list ------- '
    ap.printdict(ap.active_targets)
    print ' ----- application configuration list ------- '
    ap.printdict(ap.app_targets)

if __name__ == '__main__':
    main()
