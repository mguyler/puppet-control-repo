#!/usr/bin/python

import os, sys, threading, time, types, json
#import re, string, telnetlib, paramiko
import re, string, telnetlib
from subprocess import PIPE, Popen
from Queue import Queue, Empty
from collections import namedtuple



DEBUG = False


# match result
Response = namedtuple("Response", "index response data")

# emun
class Mode:
    shell, uboot, xorp, config, linux, ssh, ovs, pica_sh, xrl, telnet = range(10)
class Protocol:
    shell, ssh, telnet = range(3)
class Match:
    All, Match, Find, FindAll = range(4)


class ConnectionException(Exception): 
    def __init__(self, protocol):
        self.protocol = protocol
        self.msg = 'Error: %s connection is not established' % protocol

class CommandException(Exception): 
    def __init__(self, msg):
        self.msg = 'Command Exception: %s' % msg
        
class command:
    def __init__(self, cmd, prompt = None, timeout = None, \
            exception_with = None, \
            exception_without_any = None, exception_without_all = None, \
            exception_do = None, exception_msg = None):
        if isinstance(cmd, unicode):
            cmd = cmd.encode("ascii", "ignore")
        if isinstance(cmd, str):
            self.cmd = cmd
            self.prompt = prompt
            self.timeout = timeout 
            self.exception_with = exception_with
            self.exception_without_any = exception_without_any
            self.exception_without_all = exception_without_all
            self.exception_do = exception_do
            self.exception_msg = exception_msg
        elif isinstance(cmd, dict):
            self.cmd = cmd['cmd']
            self.prompt = prompt
            self.timeout = timeout 
            self.exception_with = exception_with
            self.exception_without_any = exception_without_any
            self.exception_without_all = exception_without_all
            self.exception_do = exception_do
            self.exception_msg = exception_msg
            if 'timeout' in cmd:
                self.timeout = cmd['timeout']
            if 'exception-with' in cmd:
                self.exception_with = cmd['exception-with']
            if 'exception-without-any' in cmd:
                self.exception_without_any = cmd['exception-without-any']
            if 'exception-without-all' in cmd:
                self.exception_without_all = cmd['exception-without-all']
            '''
            if 'on-exception' in cmd:
                if 'do' in cmd['on-exception']:
                    self.exception_do = cmd['on-exception']['do']
                if 'msg' in cmd['on-exception']:
                    self.exception_msg = cmd['on-exception']['msg']
            '''
            if 'exception-do' in cmd:
                self.exception_do = cmd['exception-do']
            if 'exception-msg' in cmd:
                self.exception_msg = cmd['exception-msg']
            if 'prompt' in cmd:
                self.prompt = cmd['prompt']
        else:
            raise CommandException('unable create command object - invalid type') 

class command_interface:

    def __init__(self, mode = Mode.shell, protocol = Protocol.shell, host = 'localhost', timeout = 0, prompt = None, cmd_prompt = '#', echo = True):
        self.mode = mode
        self.host = host
        #self.protocol = self._get_protocol(mode, host != 'localhost')
        self.protocol = protocol
        self.prompt = prompt
        self.timeout = timeout 
        self.sleep = 0
        self.cmd_prompt = cmd_prompt
        self.echo = echo
        self._echo = self.echo
        
    def start(self):
        if DEBUG:
            sys.stdout.write("\n--------- Mode(%s) session begin ----------\n" % self.mode)

    def stop(self):
        if DEBUG:
            sys.stdout.write("\n--------- Mode(%s) session end ----------\n" % self.mode)

    #@staticmethod
    def run_cmd(self, cmd, timeout = None, echo = True):
        f = os.popen(cmd)
        r = f.read()
        f.close()
        self.print_echo(cmd, r)
        return r
        
    #@staticmethod
    def run_only(self, cmd, sleep = 0, timeout = None):
        f = os.popen(cmd)
        time.sleep(sleep)
        f.close()
        self.print_echo(cmd, '>')

    #@staticmethod
    def run(self, cmd, run_only = False, timeout = None, sleep = None):
        cmds = []
        if type(cmd) is types.ListType:
            cmds = cmd
        else:
            cmds.append(cmd)

        result = ''
        for c in cmds:
            try:
                if run_only or (self.protocol == Protocol.shell and self.app_runonly):
                    if not isinstance(c, str):
                        # command exception
                        raise(CommandException('Invalid command type: run-only command must be a string'))
                    if sleep is None:
                        sleep = self.sleep
                    self.run_only(c, sleep, timeout)
                else:
                    #result += self.run_cmd(c, timeout) + '\n'
                    r = self.expect(c, timeout=timeout)
                    result += r[1] + '\n'
                    if r[0] < 0:
                        # command exception
                        raise(CommandException(r[2]))
            except Exception as e:
                print result
                #print e.msg
                print "Unexpected error:", sys.exc_info()[0]
                raise(e)
                exit(1)
            
        return result

    def expect(self, cmd, expected = None, timeout = None, \
            exception_with = None, exception_without_any = None, exception_without_all = None, \
            exception_handler = None, exception_msg = None):
        #r = self.extract(cmd, expected, pattern = None,  match_type = Match.All, timeout, exception_with, \
        r = self.extract(cmd, expected, None, Match.All, timeout, exception_with, \
            exception_without_any, exception_without_all, exception_handler, exception_msg)
        
        # debug
        if DEBUG:
            sys.stdout.write('\n  === ' + cmd + ' returns ' + str(r.index) + ' ===\n')
            sys.stdout.write(r.data)
            sys.stdout.flush()
        
        return r

    # cmd: string/dict/command obj, expected: list of expected prompts
    # returns (index, response, match) or (-1, response, err_msg)
    def extract(self, cmd, expected = None, \
            pattern = None, match_type = Match.All, timeout = None, \
            exception_with = None, exception_without_any = None, exception_without_all = None, \
            exception_do = None, exception_msg = None, echo = True):
            
        # cmd could be a dictionary, a command object, or a string
        if isinstance(cmd, dict):
            cmd = command(cmd)
        if isinstance(cmd, command):
            expected = cmd.prompt
            timeout = cmd.timeout 
            exception_with = cmd.exception_with
            exception_without_any = cmd.exception_without_any
            exception_without_all = cmd.exception_without_all
            exception_do = cmd.exception_do
            exception_msg = cmd.exception_msg
            cmd = cmd.cmd
        elif not isinstance(cmd, str) and not isinstance(cmd, unicode):
            return (-1, '', 'Exception: command - invalid type')
            
        if exception_msg == None:
            exception_msg = "Exception: error executing command: " + cmd
        ok = True
        
        # json file contains unicode that cannot be decoded by ascii codec
        # here instead of failing w/ UnicodeDecodeError, leave it out
        cmd = cmd.encode("ascii", "ignore")

        # execute cmd
        r = self._extract(cmd, expected, pattern, match_type, timeout, echo = echo)
        # no match found
        if r[0] < 0:
            #ok = False
            return (r[0], r[1], exception_msg + ' - timeout')
        
        # check exception-with: fail if any match 
        if ok and exception_with != None:
            for i in exception_with:
                if self.match(r[1], i) is not None:
                    # caught failure
                    ok = False
                    break
                    
        # check exception_without_any: fail if any mismatch
        if ok and exception_without_any != None:
            for i in exception_without_any:
                if self.match(r[1], i) is None:
                    # caught failure
                    ok = False
                    break
                    
        # check exception_without_all: fail if no match
        if ok and exception_without_all != None:
            ok = False
            for i in exception_without_all:
                if self.match(r[1], i) is not None:
                    # find match
                    ok = True
                    break
                
        # check if success: fail if no match found
        if not ok:
            if exception_do != None:
                # must be simple commands, no recursive error checking
                for c in exception_do:
                    c = c.encode("ascii", "ignore")
                    # rsp: Response, response: stdout text 
                    rsp, response = self.send_cmd(c, expected, timeout)
                    if rsp[0] < 0:
                        # fail again
                        exception_msg = exception_msg + "; error in " + c
                        break
            return (-1, r[1], exception_msg)

        return r
        
    # expected: list of expected prompts
    def _extract(self, cmd, expected = None, \
                pattern = None, match_type = Match.All, timeout = None, echo = False):
        if expected == None:
            expected = self.prompt
        if (timeout == None):
            timeout = self.timeout
        if pattern == None:
            match_type = Match.All

        # r: Response, response: stdout text 
        r, response = self.send_cmd(cmd, expected, timeout, None, echo = echo) 

        # no match found
        if r[0] < 0 or (expected is not None and r[0] >= len(expected)):
            #print 'extract: do nothing'
            return Response(-1, response, response)
        # return (first) match object
        elif (match_type == Match.Match):
            #print 'extract: 1st obj'
            match = self.match(response, pattern)
        # return first match string
        elif (match_type == Match.Find):
            #print 'extract: 1st string'
            match = self.findall(response, pattern)
            if match is not None and len(match) > 0:
                match = match[0]
            else:
                match = 'None'
        # return all matching strings/tuples
        elif (match_type == Match.FindAll):
            #print 'extract: all   pattern: %s' % pattern
            match = self.findall(response, pattern)
        # return raw response
        else:   # match_type == Match.All
            #print 'extract: what is this?'
            match = response
        return Response(r[0], response, match)

    # return first match object
    def match(self, theString, pattern):
        #p = re.compile(pattern)
        #match = re.search(p, theString)
        match = re.search(pattern, theString)
        #print self.displaymatch(match)
        return match

    # return an array of matched strings (or tuples if pattern is a tuple)
    def findall(self, theString, pattern):
        #p = re.compile(pattern)
        #match = re.findall(p, theString)
        match = re.findall(pattern, theString)
        #print 'str: %s  pattern: %s  match: %s' % (theString, pattern, match)
        return match

    # debug: show match object
    def displaymatch(self, match):
        if match is None:
            #return None
            return 'Match: None'
        elif type(match) is types.StringType:
            return match
        elif type(match) is types.ListType or type(match) is Response:
            return str(match)
        else:    
            span = []
            for i in range(len(match.groups()) + 1):
                span.append(match.span(i))
            return 'Match:  <%r>\nGroups: %r\nSpan:   %r' \
                   % (match.group(), match.groups(), span)
    
        if isinstance(match, re.MatchObject):    
            span = []
            for i in range(len(match.groups()) + 1):
                span.append(match.span(i))
            return 'Match:  <%r>\nGroups: %r\nSpan:   %r' \
                   % (match.group(), match.groups(), span)
        else:
            return str(match)
        
    #@abstractmethod
    def send_cmd(self, cmd, expected = None, timeout = None, sleep = None, echo = True):
        try:
            # need customization for each protocol
            data = self.run_cmd(cmd, timeout = timeout, echo = echo)
        except Exception as e:
            #print e.msg
            raise(e)
            exit(1)
        if type(sleep) is types.IntType:
            #print 'sleep: %s' % sleep
            time.sleep(sleep)

        # shell: no prompt returned
        if self.protocol == Protocol.shell:
            r = (0, data, data)
        else:
            r = self._check_match(data, expected)
        response = r[2]
        return (r, response)

    # returns (index, matched object, all_text). expected: list of expected prompts
    def _check_match(self, data, expected = None):
        index = 0
        #if expected is not None and self.protocol != Protocol.telnet:
        if expected is not None:
            for i in range(len(expected)):
                m = self.findall(data, expected[i])
                if len(m) > 0:
                    return (i, m[0], data)
            index = -1
        return (index, '', data)

    def _get_protocol(self, mode, remote):
        #if (mode in [Mode.telnet, Mode.xorp, Mode.config, Mode.pica_sh, Mode.uboot]):
        if (mode in [Mode.telnet, Mode.uboot]):
            protocol = Protocol.telnet
        elif (remote):
            protocol = Protocol.ssh
        else:
            protocol = Protocol.shell
        return protocol

    def print_echo(self, cmd, r):
        if self.echo:
            print '%s%s' % (self.cmd_prompt, cmd)
            print r,

    
class shell(command_interface):

    def __init__(self, mode = Mode.shell, sleep = 0, timeout = None, prompt = None, cmd_prompt = '# ', echo = True):
        command_interface.__init__(self, mode, 'localhost', timeout = timeout, prompt = prompt, cmd_prompt = cmd_prompt, echo = echo)
        self.protocol = Protocol.shell
        self.sleep = sleep
        self.max_size = 4096     #1024
        self.app_mode = False
        self.app_runonly = False

    # run commands
    def old_run_cmd(self, cmd, timeout = None):
        if self.app_mode:
            r = self.send(cmd, self.app_prompt, timeout)[1]
        else:
            f = os.popen(cmd)
            r = ''
            while True:
                s = f.read(self.max_size)
                if len(s) == 0:
                    break
                #r = r + s
                r = s
            f.close()
        return r

    # return output if no more than 3*max_size, or 
    #   max_size + '......' + max_size + rest
    def _run_cmd(self, cmd, timeout = None):
        if self.app_mode:
            r = self.send(cmd, self.app_prompt, timeout)[1]
        else:
            f = os.popen(cmd)
            r, r1, r2, r12 = ('', '', '', '')
            while True:
                s = f.read(self.max_size)
                if len(s) == 0:
                    break
                if r == '' and r1 == '':
                    r1 = s
                else:
                    if r != '':
                        if r2 != '':
                            r12 = '\n  ......\n'
                        r2 = r
                    r = s
            f.close()
            r2 = r2[r2.find('\n') + 1:]
            r = r1 + r12 + r2 + r
        self.print_echo(cmd, r)
        return r

    def run_cmd(self, cmd, timeout = None, echo=True):
        if self.app_mode:
            r = self.send(cmd, self.app_prompt, timeout)[1]
        else:
            #print "    program cmd: [%s]" % cmd
            proc = Popen(cmd, stdout=PIPE, stderr=PIPE, shell=True)
            (out, err) = proc.communicate()
            #print "    program output: [%s]" % out
            #print "    program error: [%s]" % err
            r = out + err
        if echo == True :
            self.print_echo(cmd, r)
        return r

    def run_only(self, cmd, sleep = None, timeout = None):
        if sleep is None:
            sleep = self.sleep
        if self.app_mode:
            r = self.send_only(cmd, sleep)
        else:
            f = os.popen(cmd)
            time.sleep(sleep)
            f.close()
            r = ''
        # no output in run_only mode 
        self.print_echo(cmd, r)
        return r
        
    def enqueue_output(self, out, queue):
        #for line in iter(out.readline, b''):
        for c in iter(lambda: out.read(1), b''):
            queue.put(c)
        out.close()

    def _send(self, cmd, prompt, timeout = 1):
        self.proc.stdin.write(cmd + '\n')
        s = ''
        while (True):
            try:  c = self.inq.get(timeout=timeout)
            except Empty:
                print('no output yet')
            else: # got char
                s = s + c
                # ... do something with line
                if prompt in s:
                    print s
                    break
            finally: 
                if not self.app_mode:
                    break
        return s

    def send_only(self, cmd, sleep = None):
        self.proc.stdin.write(cmd + '\n')
        if sleep is None:
            sleep = self.sleep
        time.sleep(sleep)
        s = ''
        while (True):
            try:  c = self.inq.get(timeout=self.timeout)
            except Empty:
                break
            else: # got char
                s = s + c
        
        return s
        
    def send(self, cmd, prompt, timeout = None, retry = 5):
        if timeout == None:
            timeout = self.timeout
        
        # send command
        self.proc.stdin.write(cmd + '\n')
        
        # receive response
        chk_prompt = False
        s = ''
        while (retry > 0):
            while (True):
                try:  c = self.inq.get(timeout=timeout)
                except Empty:
                    #print('timeout, no output yet ...')
                    print '...',
                else: # got char
                    s = s + c
                    s = s.replace(' \b', '')
                    # here assume app echoes cmd
                    if not chk_prompt and cmd in s:
                        #s = s[s.find(cmd) + len(cmd):]
                        s = s[s.find(cmd):]
                        chk_prompt = True
                    if chk_prompt:
                        for i in range(len(prompt)):
                            if prompt[i] in s:
                                return (i, s)
        
        # no prompt found, timeout
        return (-1, s)        

    # skip first prompt when app starts
    def skip(self, prompt, retry = 5):
        s = ''
        while (retry > 0):
            try:  c = self.inq.get(timeout=self.timeout)
            except Empty:
                #print('timeout, no output yet ...')
                print('..'),
                retry = retry - 1
            else: 
                s = s + c
                for i in range(len(prompt)):
                    if prompt[i] in s:
                        return s
        # timeout, return prompt
        return s        

    def app_begin(self, cmd, prompt, run_only = False, \
                  app_cmd_prompt = '> ', app_echo = True): 
        self.app_prompt = prompt
        self.app_cmd_prompt = app_cmd_prompt
        #p = Popen([cmd], stdout=PIPE, stdin=PIPE, close_fds=ON_POSIX)
        self.proc = Popen([cmd], stdout=PIPE, stdin=PIPE, bufsize=0)
        self.inq = Queue()
        self.in_thread = threading.Thread(target=self.enqueue_output, args=(self.proc.stdout, self.inq))
        #self.in_thread.daemon = True # thread dies with the program
        self.app_runonly = run_only
        self.in_thread.start()
        #print '\n =========== begin of app : %s ============\n' % cmd
        r = ''
        if not run_only:
            r = self.skip(prompt)
        self.print_echo(cmd, r)
        self.app_mode = True
        self._echo = self.echo
        self.echo = app_echo
        return r

    def app_end(self, cmd, prompt = ['']): 
        if not self.app_mode:
            return ''
        if self.app_runonly:
            r = (0, self.send_only(cmd, sleep = 1))
        else:
            r = self.send(cmd, prompt)
        self.in_thread.join()
        #print '\n =========== end of app ============\n'
        self.app_runonly = False
        self.print_echo(cmd, r[1])
        self.app_mode = False
        self.echo = self._echo
        return r[1]

    def _print_echo(self, cmd, r):
        if self.app_mode and self.echo:
            print self.app_cmd_prompt,
        else:
            print self.cmd_prompt,
        command_interface.print_echo(self, cmd, r)

    def print_echo(self, cmd, r):
        if self.echo:
            if self.app_mode:
                print self.app_cmd_prompt,
            else:
                print self.cmd_prompt,
            print '%s' % cmd
        print r,    
        #command_interface.print_echo(self, cmd, r)
       
# Note: only telnet will grab everything includes prompt
class telnet(command_interface):

    ACCOUNT = "admin"
    PASSWORD = "pica8"
    DEFAULT_PROMPTS = ['root@XorPlus>', '\r\n.+@.+[#>:]', '\r.*@.*[#>:]', '\n.+@.+[#>:]', 'XorPlus[#>]']
    COMMAND_PROMPTS = {Mode.xorp : 'XorPlus#', Mode.config : 'XorPlus>', Mode.pica_sh : 'XorPlus#', Mode.uboot : '>', Mode.shell : '[@#]'}

    #def __init__(self, mode = Mode.xorp, user = telnet.ACCOUNT, passwd = telnet.PASSWORD, host='localhost', timeout = 10, prompt = telnet.DEFAULT_PROMPTS):
    def __init__(self, mode = Mode.xorp, user = ACCOUNT, passwd = PASSWORD, host='localhost', sleep = 0.5, prompt = DEFAULT_PROMPTS, timeout = 10, echo = False):
        command_interface.__init__(self, mode = mode, host = host, protocol = Protocol.telnet, echo = echo)
        self.user = user
        self.passwd = passwd
        self.prompt = prompt
        self.sleep = sleep               # sleep after each command
        self.timeout = timeout           # max waiting for prompt
        #self.protocol = Protocol.telnet
        self.telnet = telnetlib.Telnet()
        if self.mode in [Mode.xorp, Mode.config, Mode.pica_sh, Mode.uboot]:
            self.command_prompt = telnet.COMMAND_PROMPTS[self.mode]
        else:
            self.command_prompt = ''
        self.ready = False

    def start(self):
        self.telnet.open(self.host)
        t = self.telnet
        t.read_until("login: ")
        t.write(self.user + "\n")
        t.read_until("Password: ")
        t.write(self.passwd + "\n")
        t.expect(self.prompt, 5)
        self.ready = True
        if DEBUG:
            sys.stdout.write("\n--------- rpc session begin ----------\n")

    def stop(self):
        self.run_only('')
        time.sleep(self.sleep)
        self.telnet.close()
        response = self.telnet.read_all()
        sys.stdout.write(response)
        self.ready = False
        if DEBUG:
            sys.stdout.write("\n--------- rpc session end ----------\n")

    #@staticmethod
    def run_cmd(self, cmd, sleep = None, timeout = None, echo = True):
        if not self.ready:
            raise ConnectionException('telnet')
        
        r = self._run_cmd(cmd)
        if echo == True :
            self.print_echo(cmd, r[1])
        return r[1]

    #@staticmethod
    def run_only(self, cmd, sleep = None, timeout = None):
        if not self.ready:
            raise ConnectionException('telnet')
        
        if (sleep == None):
            sleep = self.sleep
        if (timeout == None):
            timeout = self.timeout
        t = self.telnet
        t.write(cmd + '\n')
        expected = self.prompt
        self._check_mode(cmd, expected)
        time.sleep(self.sleep)
        t.expect(expected, self.timeout)
        self.print_echo(cmd, '>')

    # do not use it directly because telnet.expect searches all expected and returns first
    # match in text, and tcl expect() searches in the order of index in expected
    def _run_cmd(self, cmd, expected = None, timeout = None, sleep = None):
        if sleep == None:
            sleep = self.sleep
        if timeout == None:
            timeout = self.timeout           
        if expected == None:
            expected = self.prompt

        t = self.telnet
        t.write(cmd + '\n')
        self._check_mode(cmd, expected)
        time.sleep(sleep)
        r = t.expect(expected, timeout)
        response = r[2] + t.read_very_eager()
        return (r, response)
    
    # XorPlus only: check if change mode
    def _check_mode(self, cmd, expected):
        if self.mode in [Mode.xorp, Mode.config, Mode.pica_sh]: #, Mode.uboot]:
            if (cmd == "configure" and self.mode == Mode.xorp):
                self.mode = Mode.config
            elif ((cmd == "exit" or cmd == "quit") and self.mode == Mode.config):
                self.mode = Mode.xorp
            elif ((cmd == "exit" or cmd == "quit") and self.mode == Mode.xorp):
                self.mode = Mode.shell
            self.command_prompt = telnet.COMMAND_PROMPTS[self.mode]
            # make sure we have command_prompt
            if (self.mode != Mode.shell and self.command_prompt not in expected):
                expected.append(self.command_prompt)

   
class ssh(command_interface):

    ACCOUNT = "root"
    PASSWORD = "pica8"

    def __init__(self, mode = Mode.ssh, user = ACCOUNT, passwd = PASSWORD, host = '127.0.0.1', echo = False):
        command_interface.__init__(self, mode = mode, host = host, protocol = Protocol.telnet, echo = echo)
        self.user = user
        self.passwd = passwd
        #self.protocol = Protocol.ssh
        self.client = paramiko.SSHClient()
        self.ready = False

    def start(self):
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(self.host, username=self.user, password=self.passwd)
        self.ready = True
        if DEBUG:
            sys.stdout.write("\n--------- SSH session begin ----------\n")

    def stop(self):
        self.client.close()
        self.ready = False
        if DEBUG:
            sys.stdout.write("\n--------- SSH session end ----------\n")

    # run commands
    #@staticmethod
    def run_cmd(self, cmd, sleep = None, timeout = None, echo = True):
        if not self.ready:
            raise ConnectionException('SSH')
        stdin, stdout, stderr = self.client.exec_command(cmd)
        return stdout.read()

    #@staticmethod
    def run_only(self, cmd, sleep = 0, timeout = None):
        if not self.ready:
            raise ConnectionException('SSH')
        stdin, stdout, stderr = self.client.exec_command(cmd)


class xorp(telnet):
    def __init__(self, host='localhost'):
        telnet.__init__(self, Mode.xorp, telnet.ACCOUNT, telnet.PASSWORD, host)

    # xorplus command line interface 


class ovs(shell):
    def __init__(self):
        shell.__init__(self, Mode.ovs)

    # ovs command line interface 


class xrl(shell):
    def __init__(self):
        shell.__init__(self, Mode.xrl)
        self.xrl = '/pica/bin/libxipc/call_xrl "finder://'

    # run commands
    #@staticmethod
    def run_cmd(self, cmd, echo = True):
        c = '%s%s"' % (self.xrl, cmd)
        return shell.run_cmd(self, '%s%s"' % (self.xrl, cmd))

    #@staticmethod
    def run_only(self, cmd, sleep = 0.5):
        shell.run_only(self, self.xrl + cmd, sleep)


def main():
    test_expect()
    

def test_expect():

    print '\n=========== Start picacommand class test ============\n'

    host = '127.0.0.1'
    shell_cmds = ['cd /', 'pwd', 'df', 'ps -ef | grep xorp', 'ifconfig | grep Bcast']
    std_promts = ['root@XorPlus>', "XorPlus>", "XorPlus#", "#", "> "]

    # shell and OVS
    #e = telnet(mode = Mode.xorp, user = 'root', passwd = 'pica8', host = host, sleep = 0.5)
    e = shell()

    print '\n   -------- Begin of shell testing --------\n'
    e.start()

    print '\n   -------- run --------\n'
    print e.run(shell_cmds)

    print '\n   -------- extract and expect --------\n'
    # test expect and extract
    pattern = '(\/\w+\/\w+)\s.*\s(\d+%)\s(\/.*)[\r\n]'
    match = e.extract("df", std_promts, pattern, Match.Match, 1)
    #print match.response
    print "\n   ------ Match ------\n"
    print e.displaymatch(match.data)   
    print "\n   ------ Find ------\n"
    match = e.extract("df", std_promts, pattern, Match.Find, 2)
    print match    
    print "\n   ------ FindAll ------\n"
    match = e.extract("df", std_promts, pattern, Match.FindAll, 2)
    print match    
    print "\n   ------- expect -----\n"
    match = e.expect("df")
    print match 
    
    e.stop()    
    print '\n   -------- End of shell testing --------\n'
    
    # XorPlus
    print '\n   -------- Beginning of XorPlus testing --------\n'

    e = telnet(Mode.xorp, 'root', 'pica8', host, 0.5, echo = False)
    e.start()
    
    rsp = e.expect('/pica/bin/pica_sh', ["XorPlus> ", "Password: ", "password:"], 10)
    if (rsp[0] == 0):
        print(rsp[2])
    elif (rsp[0] > 0):
        rsp = e.expect('"pica8', ["XorPlus> "])
        print rsp
    else:
        print rsp
        # dumb terminal
        e.telnet.mt_interact()
        sys.stdout.write(e.telnet.read_all())
        return

    if (rsp[0] == 0):
        print("\n === Enter XorPlus =====\n")
        xorp_promts = ["Commit", "mac_phy", "XorPlus>", "XorPlus#", "#", "> "]
        xorp_cmds = ['configure', 'help', \
                     'set protocols lldp hold-time-multiplier 5', \
                     'commit', \
                     'run show lldp detail', \
                     'set protocols lldp hold-time-multiplier 2', \
                     'commit', \
                     'run show lldp detail', \
                     'show interface gigabit-ethernet te-1/1/1', \
                     'set interface gigabit-ethernet te-1/1/1 speed 10000', \
                     'commit', \
                     'show interface gigabit-ethernet te-1/1/1', \
                     'set interface gigabit-ethernet te-1/1/1 speed 1000', \
                     'commit', \
                     'show interface gigabit-ethernet te-1/1/1', \
                     'quit']
        print e.expect('show system os', xorp_promts)[1]
        print e.run(xorp_cmds, xorp_promts)

        # !!! need to check following 2 lines
        for c in xorp_cmds:
            print e.expect(c, xorp_promts)[1]

        print e.expect('show system date', xorp_promts)[1]
        print e.expect('exit', xorp_promts)[1]

    print '\n   -------- End of XorPlus testing --------\n'

    e.stop()

    print '\n   -------- command with exceptions --------\n'
    e = shell()
    e.start()

    action = [
        "pwd",
        {"cmd":"ls -l",
         "exception-with":["provision-target.lst"],
         "exception-without-all":["config.bcm", "rc.soc", "selinux", "ap_cfg.py"],
         "exception-without-any":["dispatcher", "ap_mgr", "script"],
         "exception-do":["df", "date"],
         "exception-msg":"Test error: ls -l"
        },
        "version",
        {"cmd":"ls -l /var/spool/cron",
         "exception-without-any":["crontab", "\w+\s+\d+\s+[\d:]+"],
         "exception-msg":"tar error: rootfs.tar.gz extract incomplete"
        },
        "uname -a"
    ] 
    print "\n   ------- cmd list -----\n"
    for i in action:
        print e.expect(i)
    print "\n   ------- run -----\n"
    e.run(action)

    e.stop()
    print '\n=========== End picacommand class test ============\n'


if __name__ == '__main__':
    main()

