#!/usr/bin/env python

# Pica8 script tool in python

import json
import os
from picascript import PicaExpect
from picacommand import Protocol, Mode, command


# contants: will be in config file
PROMPTS = ["root@XorPlus#", "#", "tftp> "]
TIMEOUT = 15
     
     
class ap_task(PicaExpect):
    def __init__(self, prompt = PROMPTS, timeout = TIMEOUT, mode = Mode.shell, cmd_prompt = '# ', echo = True):
        # append prompt to default
        prompts = list(PicaExpect.DEFAULT_PROMPTS)
        prompts.extend(prompt)    
        # init PicaExpect object
        #PicaExpect.__init__(self, prompt = prompts, timeout = timeout, cmd_prompt = cmd_prompt, echo = echo)
        PicaExpect.__init__(self, mode = mode, prompt = prompts, \
              timeout = timeout, cmd_prompt = cmd_prompt, echo = echo)
        self.tftpserver = ''
        self.eth0 = ''
        self.gateway = ''

    # tcl like expect: returns index
    def cmd(self, cmd, prompt = None, timeout = 30):
        r = PicaExpect.expectplus(self, cmd, prompt, timeout)
        #print 'Auto-Provisioning> %s\n%s', % (cmd, r[1])
        return r[0]

    # returns tuple: (index, output, output/err_msg)
    def expect(self, cmd, prompt = None, timeout = 30):
        return PicaExpect.expectplus(self, cmd, prompt, timeout)
        
    # returns 1st extracted data
    def extract(self, cmd, pattern, prompt = None, timeout = 30, echo = True):
        r = self.extract_all(cmd, pattern, prompt, timeout, echo = echo)
        if r == None or r == []:
            return ''
        else:
            return r[0]
        
    # returns all extracted data as a list
    def extract_all(self, cmd, pattern, prompt = None, timeout = 30, echo = True):
        return PicaExpect.extract(self, cmd, pattern, prompt, timeout, echo = echo)[2]
        
    def switch(self):
        self.switch_info()
        return {'model':self.model, 'version':self.version, 'revision':self.revision, 'mac':self.mac, 'sn':self.sn, 'ip':self.eth0, 'gateway':self.gateway}
         
    def switch_info(self):
        cmd = 'version | grep "Hardware model"'
        self.model = self.extract(cmd, ': P-(\d+)', echo = False)
        cmd = 'version | grep "PicOS Version"'
        self.version = self.extract(cmd, ': ([\d\.]+)', echo = False)
        cmd = 'version | grep "Software Revision"'
        self.revision = self.extract(cmd, ': (\d+)', echo = False)
        cmd = '/pica/bin/system/fan_status -s | grep "MotherBoard Serial Number"'
        self.sn = self.extract(cmd, ': ([\w]+)', echo = False)
        cmd = 'ifconfig eth0 | grep HWaddr'
        self.mac = self.extract(cmd, 'HWaddr ([A-Fa-f\d:]+)', echo = False)
        if (self.model == '' or self.version == '' or self.revision == '' or \
            #self.sn == '' or self.mac == ''):
            self.mac == ''):
            self.on_error('Failed to get switch info')

    # check if link up
    def get_ipaddr(self):
        cmd = 'ifconfig eth0 | grep "inet addr"'
        ip = self.extract(cmd, 'inet addr:([\d\.]+) ', echo = False)
        return ip

    # default route address
    def get_gateway(self):
        cmd = 'route | grep "default"'
        ip = self.extract(cmd, 'default\s+([\d\.]+) ', echo = False)
        return ip

    # connect to mgmt port
    def connect(self):
        # check if link up
        ip = self.get_ipaddr()
        if ip != '':
            self.eth0 = ip
            return True
            
        # get IP from DHCP lease if self.eth0 not set
        if (self.eth0 == ''):
            # get tftp server IP address
            cmd = 'grep -a fixed-address /var/lib/dhcp/dhclient.eth0.leases | tail -1'
            self.eth0 = self.extract(cmd, 'fixed-address ([\d\.]+);')

        # try self.eth0 as static IP address
        if (self.eth0 != ''):
            cmd = 'ifconfig eth0 ' + self.eth0 + '/24'
            self.cmd(cmd)
            self.sleep(5)
            
        return self.get_ipaddr() != ''                
        
    # start dhcp client to get connected
    def dhcpclient(self):
        #pid = self.extract('ps -ef | grep dhclient', '\w+\s+(\d+)\s+\d+.+eth0')
        pid = self.extract('cat /run/dhclient.eth0.pid', '(\d+)', echo = False)
        #pid = self.extract("ps -ef | grep -v grep | grep dhclient | grep eth0 | awk '{print $2}'", '(\d+)')
        if pid is None or pid == '':
            r = self.expect('dhclient -pf /run/dhclient.eth0.pid -lf /var/lib/dhcp/dhclient.eth0.leases eth0', None, 20)[1]
            # wait link up
            self.printline('  DHCP - start shclient, waiting for link up')
            self.sleep(8)
            self.printline(self.expect('ifconfig', None, 20)[1])
            pid = self.extract('cat /run/dhclient.eth0.pid', '(\d+)')
            self.cmd('kill -9 ' + pid)
            self.cmd('rm /run/dhclient.eth0.pid')
        else:
            status = self.extract('cat /sys/class/net/eth0/operstate', '(\w+)', echo = False)
            if status != "up" :
                self.printline(' DHCP - waiting for link up\n')
                self.sleep(5)
            
        self.eth0 = self.get_ipaddr()
        self.printline(' IP address: ' + self.eth0)
        return self.eth0 != ''

    def check_status_partition_two(self):
        #res = self.expect('grep secondary /etc/picos/fs_status')
        #if "ok" not in res[1] and "up-to-date" not in res[1]:
        res = self.extract('grep secondary /etc/picos/fs_status', '(.*)', echo = False)
        if "ok" not in res and "up-to-date" not in res:
            return False
        return True

    # get provision script file from TFTP server
    def get_tftp_server_info(self):
        # get connected 
        if not self.connect():
            self.on_error('Unable to get IP address')
        
        # get tftp server IP address
        cmd = 'grep -a tftp-server-name /var/lib/dhcp/dhclient.eth0.leases | tail -1'
        self.tftpserver = self.extract(cmd, 'tftp-server-name \"([\d\.]+)\";', echo = False)
        if (self.tftpserver == ''):
            cmd = 'grep -a server-name /var/lib/dhcp/dhclient.eth0.leases | tail -1'
            self.tftpserver = self.extract(cmd, 'server-name \"([\d\.]+)\";', echo = False)
            if (self.tftpserver == ''):
                #print('server name = %s' % self.extract(cmd, 'server-name \"([\d\.]+)\";'))
                #print('server name = %s' % self.extract(cmd, 'server-name "([\d\.]+)";'))
                #print('server name = %s' % self.extract(cmd, 'server-name \"([\d\.]+)\"'))
                #self.on_info('Failed to get tftp server IP address')
                self.on_exit_normal_info('No auto-provisioning configuration')
            else :
                print(' server name = %s' % self.tftpserver)
        else :
            print(' server name = %s' % self.tftpserver)

                
        # get bootfile name
        cmd = 'grep -a bootfile-name /var/lib/dhcp/dhclient.eth0.leases | tail -1'
        self.bootfile = self.extract(cmd, 'bootfile-name \"([a-zA-Z0-9_\./]+)\";', echo = False)
        if (self.bootfile == ''):
            cmd = 'grep -a filename /var/lib/dhcp/dhclient.eth0.leases | tail -1'
            self.bootfile = self.extract(cmd, 'filename \"([a-zA-Z0-9_\./]+)\";', echo = False)
            if (self.bootfile == ''):
                self.on_error('Failed to get bootfile name')
            else :
                print(' bootfile name = %s' % self.bootfile)
        else :
            print(' bootfile name = %s' % self.bootfile)
                
    # get provision script file from TFTP server
    def get_script_file(self):
        # get mgmt port connected, and get tftpserver ip and bootfile name
        self.get_tftp_server_info()

        # get provision script, copy to /cftmp
        self.tftp_get_file([self.bootfile], dest = '/cftmp/')

        # strip any path in bootfile before reading
        self.bootfile = self.bootfile[self.bootfile.rindex('/') + 1:]
        file = '/cftmp/' + self.bootfile

        return file
        
    '''        
    # !!! moved to ap_dispatcher.py
    # provision script in JSON format
    def read_script(self, script_file):
        script = None
        try:
            f = open(script_file, "r")
            data = f.read()
            script = json.loads(data)
        except IOError:
            self.on_error('  *** Error open/read script file : %s\n' % script_file)
        finally:
            f.close()
            
        return script
    '''

    # default path: src = /tftpboot dest = .  
    def tftp_get_file(self, files, path = '', dest = './'):    
        # get tftp server IP address if not set
        if self.tftpserver is None or self.tftpserver == '':
            self.get_tftp_server_info()
        
        # make sure paths are in same format
        if len(path) > 0 and path[len(path)-1] != '/':
            path = path + '/'
        if dest == '':
            dest = './'
        elif dest[len(dest)-1] != '/':
            dest = dest + '/'
            
        r = None

        for file in files:
            f = path + file
            # strip any path in bootfile before reading
            file = f[f.rfind('/') + 1:]
            tftp = 'atftp --option "blksize 4096" -g -r ' + f + ' -l ' + dest + file + ' ' + self.tftpserver #+ ' >/tmp/tftp_status 2>&1'
            cmd = command(tftp, exception_with = ['error', 'not found', 'abort', 'violation', 'nknown', 'llegal', 'ot defined'], exception_do = ['rm ' + dest + file], exception_msg = 'failed downloading ' + file)
            r = self.expect(cmd)
            if r[0] < 0:
                re_tries = 3
                while re_tries > 0:
                    r = self.expect(cmd)
                    if r[0] > -1:
                        break
                    re_tries -= 1

            # skip rest files
            if r[0] < 0:
                break
            
        return r
    
    def tftp_put_file(self, files, path = '', dest = ''):
        # get tftp server IP address if not set
        if self.tftpserver is None or self.tftpserver == '':
            self.get_tftp_server_info()

        # make sure paths are in same format
        if len(path) > 0 and path[len(path)-1] != '/':
            path = path + '/'
        if dest == '':
            dest = ''
        elif dest[len(dest)-1] != '/':
            dest = dest + '/'

        r = None
        for file in files:
            f = path + file
            # strip any path in bootfile before reading
            file = f[f.rfind('/') + 1:]
            tftp = 'atftp --option "blksize 4096" -p -l ' + f + ' -r ' + dest + file + ' ' + self.tftpserver #+ ' >/tmp/tftp_status 2>&1'
            cmd = command(tftp, exception_with = ['error', 'not found', 'abort', 'violation', 'nknown', 'llegal', 'ot defined'], exception_do = ['rm ' + dest + file], exception_msg = 'failed downloading ' + file)
            r = self.expect(cmd)
            if r[0] < 0:
                re_tries = 3
                while re_tries > 0:
                    r = self.expect(cmd)
                    if r[0] > -1:
                        break
                    re_tries -= 1

            # skip rest files
            if r[0] < 0:
                break

        return r

    # task operations
    def do_task(self, task):
        if task["type"] == "copy-to":
            return self.copy_to(task)
        elif task["type"] == "copy-from":
            return self.copy_from(task)
        elif task["type"] == "tftp-get":
            return self.tftp_get(task)
        elif task["type"] == "tftp-put":
            return self.tftp_put(task)
        elif task["type"] == "actions":
            self.actions(task)
        elif task["type"] == "reboot":
            return self.reboot(task)
        elif task["type"] == "application":
            return self.application(task)
        elif task["type"] == "image-upgrade:pica":
            return self.image_upgrade(task)
        elif task["type"] == "image-upgrade:picos":
            return self.image_upgrade(task)
        elif task["type"] == "actions:ovs":
            return self.actions(task)
        elif task["type"] == "actions:xorp":
            return self.actions(task)
        #elif task["type"] == "picos-application":
        #    self.picos_application(task)
        elif task["type"] == "picos-service":
            r = self.picos_service(task['service'],task['action'] )
            if r != task['service']:
                self.on_error_without_exit(r)
                return False
            return True
        else:
            self.on_error("undefined task %s" % task["type"])

    def copy_to(self, task):
        # assert: type == "copy-to"
        if not os.path.isdir(task["destination"]):
            if os.path.isfile(task["destination"]) or os.path.islink(task["destination"]):
                os.remove(task["destination"])
            os.mkdir(task["destination"])
        for i in task["item"]:
            f = task["file"][i]
            cp_cmd = 'cp -fr ' + f + ' ' + task["destination"]
            cmd = command(cp_cmd, exception_with = ['error', 'cannot stat', 'No such file or directory'], 
                            exception_do = ['rm -fr ' + task["destination"] +'/' + f], 
                            exception_msg = 'failed copy ' + f + ' to ' + task["destination"])
            r = self.expect(cmd)
            #self.cmd(cmd)
            if r[0] < 0:
                self.on_error_without_exit(r[2])
                return False
        return True
            
            
    def copy_from(self, task):
        # assert: type == "copy-from"
        for i in task["item"]:
            f = task["file"][i]
            fname = f[f.rfind("/") + 1:]
            #self.cmd('cp -fr ' + task["source"] + '/' + fname + ' ' + f)
            cp_cmd = 'cp -fr ' + task["source"] + '/' + fname + ' ' + f
            cmd = command(cp_cmd, exception_with = ['error', 'cannot stat', 'No such file or directory'], 
                            exception_do = ['rm -fr ' + f], 
                            exception_msg = 'failed copy ' + f + ' from ' + task["source"])
            r = self.expect(cmd)
            #self.cmd(cmd)
            if r[0] < 0:
                self.on_error_without_exit(r[2])
                return False
        return True
                
    def tftp_get(self, task):
        files = []
        for i in task["item"]:
            if self.model in task and i in task[self.model]:
                files.append(task[self.model][i])
            elif i in task['all']:
                files.append(task['all'][i])
            else:
                self.on_error_without_exit("Error: tftp-get - file " + i + " is not defined")
                return False

        #self.cmd('cd ' + task["destination"])
        if "source" in task:
            src = task["source"]
        else:
            src = ''            
        if "destination" in task:
            dest = task["destination"]
        else:
            dest = './'
            
        r = self.tftp_get_file(files, src, dest)
        if r[0] < 0:
            self.on_error_without_exit(r[2] + '\n' + r[1])
            return False
        return True
         
    def tftp_put(self, task):
        files  = []
        for i in task["item"]:
            if self.model in task and i in task[self.model]:
                files.append(task[self.model][i])
            elif i in task['all']:
                files.append(task['all'][i])
            else:
                self.on_error_without_exit("Error: tftp-put - file " + i + " is not defined")
                return False

        #self.cmd('cd ' + task["destination"])
        if "source" in task:
            src = task["source"]
        else:
            src = ''
        if "destination" in task:
            dest = task["destination"]
        else:
            dest = ''

        r = self.tftp_put_file(files, src, dest)
        if r[0] < 0:
            self.on_error_without_exit(r[2] + '\n' + r[1])
            return False
        return True
        
    # system reboot
    #    "reboot": {
    #        "type": "reboot",
    #        "action": [ "reboot" ]
    #    },
    def reboot(self, task):
        #command = '{0}'.format(task["action"])
        #self.cmd(command, timeout = 600)
        self.cmd(task["action"][0], timeout = 600)
        return True


    # pica/picos image upgrade
    #    "pica-upgrade": {
    #        "type": "image-upgrade:pica",
    #        "image": "pica8/pica-@{picos-version}-@{model}-r@{picos-revision}.tar.gz" 
    #    },
    def image_upgrade(self, task):
        if "image-upgrade" not in task['type'] or 'image' not in task:
            self.on_error('Error: required fields missing in image-upgrade task')
        type = task['type'].split(':')
        # we support picos and pica images
        if len(type) < 2 or type[1] not in ['pica', 'picos']:
            self.on_error_without_exit('Error: no valid image type in image-upgrade task')
            return False
        image_type = type[1]
        image = task["image"]

        if "source" in task:
            src = task["source"]
        else:
            src = ''
        
        # download image file to current directory        
        r = self.tftp_get_file([image], path = src, dest = '/cftmp/')
        self.cmd("sync")
        if r[0] < 0:
            self.on_error_without_exit(r[2] + '\n' + r[1])
            return False
           
        # strip path from file name
        image = image[image.rfind('/') + 1:]

        if image_type == "picos":
            # upgrade picos 
            #command = 'mv /cftmp/{0} /cftmp/rootfs.tar.gz'.format(image)
            command = 'mv /cftmp/' + image + ' /cftmp/rootfs.tar.gz'
            self.cmd(command)
            #self.cmd("ls /cftmp/rootfs.tar.gz")
            # make sure reboot: insert a reboot task?
            #self.cmd("reboot")
        else:
            # update pica here
            #command = 'mv /cftmp/{0} /cftmp/pica.tar.gz'.format(image)
            command = 'mv /cftmp/' + image + ' /cftmp/pica.tar.gz'
            self.expect(command)
            self.cmd("rm -rf /pica/etc/templates/")
            self.cmd("tar zxvf /cftmp/pica.tar.gz -C /")
            self.cmd("rm /cftmp/pica.tar.gz")
            self.cmd("echo 'wait a minute, sync the data to disk ...'")
            self.cmd("sync")
            self.cmd("echo 'Pica package upgrading finished. Restart now ...'")
            # make sure reboot: insert a reboot task?
            #self.cmd("reboot")

        return True
    
    # set picos start option 
    def set_picos_start_option(self, choice):

        # check choice
        if (choice < 1 or choice > 3):
            return "invalid choice"
        elif choice == 3:
            option = ''
        elif choice == 2:
            option = 'ovs'
        else:
            option = 'xorpplus'

        # set picos start option        
        cmd = "grep picos_start /etc/picos/picos_start.conf"
        optn = self.expect(cmd)[1].rstrip('\n')
        cmd = "sed -i 's|" + optn + "|picos_start=" + option + "|g' /etc/picos/picos_start.conf"    
        self.cmd(cmd)        
        
        # check if ovs network configured
        if choice == 2:        
            #ip = '10.10.10.11'
            #gateway = '10.10.10.1'
            self.ip = self.get_ipaddr()
            self.gateway = self.get_gateway()        
            cmd = "grep ovs_switch_ip_address /etc/picos/picos_start.conf"
            ovs_ip = self.expect(cmd)[1].rstrip('\n')
            
            # set ovs network info
            if self.ip not in ovs_ip:
                cmd = "sed -i 's|" + ovs_ip + "|ovs_switch_ip_address=" + self.ip + "|g' /etc/picos/picos_start.conf"
                self.cmd(cmd)        
                cmd = "grep ovs_switch_gateway_ip /etc/picos/picos_start.conf"
                ovs_ip = self.expect(cmd)[1].rstrip('\n')
                cmd = "sed -i 's|" + ovs_ip + "|ovs_switch_gateway_ip=" + self.gateway + "|g' /etc/picos/picos_start.conf"
                self.cmd(cmd)        

    # current picos service mode
    def picos_service_status(self):
        service = "shell"
        r = self.expect("service picos status")
        if "xorp_rtrmgr is running" in r[1]:
            service = "xorp"
        elif "ovsdb-server is running" in r[1]:
            service = "ovs"                
        return service
    
    # service: xorp/ovs/shell, action: status/stop/start/restart/set
    def picos_service(self, service, action):
    
        # what's running now        
        status = self.picos_service_status()
        
        # check action            
        if action == "status":
            return status
        elif action== "stop":
            if status == "shell":
                return "picos service stopped"
            else:
                self.cmd("service picos " + action, timeout = 20)
                if self.picos_service_status() == "shell":
                    return "picos service stopped"
                else:
                    return "Error: picos service not stopped"            
        elif action not in ["start", "restart", "set"]:
            return "Error: invalid picos service action"
            
        # check service
        if service not in ["xorp", "ovs", "shell"]:
            return "Error: invalid picos service %s" % service    

        if service in ["xorp"] and status != "xorp":
            option = 1
            self.set_picos_start_option(option)
        elif service == "ovs" and status != "ovs":
            # we may need ip address here
            self.ip = self.get_ipaddr()
            self.gateway = self.get_gateway()
            option = 2
            self.set_picos_start_option(option)
        elif service == "shell" and status != "shell":
            option = 3
            self.set_picos_start_option(option)
        #else:
        #    return status    
        
        # start picos service
        if action in ["start", "restart"]:
            # start service
            command = "service picos {0}".format(action)
            self.cmd(command)
            status = self.picos_service_status()
            if service != status:
                return "Error: failed to start service: " + service 
        return status

    # execute actions task
    def do_actions(self, actions, prompt, timeout, sleep, errmsg):

        for c in actions:
            #print '  - do_action: cmd=%s' % c
            if isinstance(c, unicode):
                c = c.encode("ascii", "ignore")
            if isinstance(c, str):
                # simple command
                r = self.expect(c, prompt, timeout)            
            elif isinstance(c, dict):
                if 'cmd' in c:
                    print' command obj: %s' % str(c)
                    # command object
                    r = self.expect(c, prompt, timeout)
                elif 'script' in c:
                    print' command script: %s' % str(c)
                    # command list file
                    file = c['script']
                    if isinstance(file, unicode):
                        file = file.encode("ascii", "ignore")
                  
                    # app: interactive mode
                    if self.ci.app_mode:
                        # to do: add check if file cannot open
                        f = open(file, 'r')
                        clist = [line.rstrip('\n') for line in f]
                        f.close()
                        for cmd in clist:
                            if isinstance(cmd, unicode):
                                cmd = cmd.encode("ascii", "ignore")
                            r = self.expect(cmd, prompt, timeout)
                            if r[0] < 0:
                                break
                            self.sleep(sleep)
                    else:
                        # shell: run file as shell script
                        if not '/' in file:
                            file = './' + file
                        cmd = '. ' + file
                        r = self.expect(cmd, prompt, timeout)
            else:
                print' what type %s is this command: %s   ' % (tyep(c), c)

            if r[0] < 0:
                self.on_error_without_exit(errmsg + ' - action: ' + c)
                return False
            self.sleep(sleep)
        
        return True         
    # actions task    
    #    "custmer-upgrade": {
    #        "type": "actions",
    #          "download": ["custmer.sh", "customer2.sh"],
    #        "action": [
    #            "source ./custmer.sh > ./custmer.log",
    #            {"script": "xorp.cli"}
    #        ]
    #        "timeout": 15, 
    #        "on-error": "Error: failed in XorPlus configuration"
    #    },
    def actions(self, task):
        # assert: type == "actions"    
        if "actions" not in task['type'] or 'action' not in task:
            self.on_error('Error: required fields missing in actions task')
        type = task['type'].split(':')
        # we support 2 picos actions types: xorp and ovs
        if len(type) < 2:
            actions_type = 'shell'
        elif type[1] in ['xorp', 'ovs']:
            actions_type = type[1]
        else:
            self.on_error_without_exit('Error: no valid actions type in actions task')
            return False

        if  "prompt" in task and task["prompt"] != "default":
            prompt = task["prompt"]
        else:
            #prompt = self.prompts
            prompt = PROMPTS
        error_msg = "Error executing task "
        if  "on-error" in task:
            error_msg = task["on-error"]
        if  "timeout" in task:
            timeout = task["timeout"]
        else:
            #timeout = self.timeout
            timeout = 10
        if  "sleep" in task:
            sleep = task["sleep"]
        else:
            #sleep = self.sleep
            sleep = 1
        if 'download' in task:
            # download files in current directory        
            r = self.tftp_get_file(task['download'])
            if r[0] < 0:
                self.on_error_without_exit(r[2] + '\n' + r[1])
                return False
           
        # start picos service
        if actions_type in ['xorp', 'ovs']:
            status = self.picos_service_status()
            if status != actions_type:
                 r = self.picos_service(actions_type, 'restart')
                 if r != actions_type:
                     self.on_error_without_exit(r)
                     return False
        
        # xorp: start application session in shell mode
        if actions_type == 'xorp':
            print self.start_app_session('/pica/bin/pica_sh', ['XorPlus>', 'XorPlus#'], run_only = False, app_cmd_prompt = '', app_echo = False),    
            
        # execute actions task
        act_res = self.do_actions(task['action'], prompt, timeout, sleep, error_msg)
                
        # xorp: start application session in shell mode
        if actions_type == 'xorp':
            print self.stop_app_session('quit')

        return act_res

    # check if telnet server is running
    def has_telnet():
        return False

    # application session actions
    def application(self, task):
        if not self.has_telnet():
            # shell mode
            print self.start_app_session(task["start"], task["prompt"]),
            self.app_actions(task)
            print self.stop_app_session(task["stop"])
            return True

        # telnet mode
        # creat application session
        session = self.app_session(prompt = task["prompt"])
        # start session 
        r = self.start_session(session, task["start-cmd"])
        if r[0] < 0:
            self.on_error("Error starting application session %s" % task["start-cmd"])

        # do actions
        session.app_actions(task)

        # exit to main session
        r = self.stop_session(session, task["exit-cmd"])
        if r[0] < 0:
            self.on_error("Error stopping application session %s" % task["start-cmd"])
                
    # to do: allow extract, etc
    def app_actions(self, task):
        # assert: type == "actions"
        for i in task["item"]:
            t = task["task"][i]
            for c in t["action"]:
                print self.run(c),


def main():
    # test dhcp lease
    #test_lease()
    #boot_option_test()
    
    #test_exception()
    task_test()

def test_exception():

    #e = ap_task(mode=Mode.telnet)
    #e = ap_task(mode=Mode.ssh)
    e = ap_task(mode=Mode.shell, timeout = 2)
    e.start()

    long_echo = 'echo "set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24 set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24 set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24 set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24 set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24 set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24 set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24 set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1prefix-length 24"'
    print '\n   -------- long command --------\n'
    e.expect(long_echo)
    print '\n   -------- long command in sh --------\n'
    e.start_app_session('sh', ['# '], run_only = True, app_cmd_prompt = ' # ')
    #e.start_app_session('sh -v', ['# ', '#'], run_only = False, app_cmd_prompt = ' # ')
    e.run('pwd', sleep = 1),
    e.run('ls', sleep = 1),
    e.run(long_echo, sleep = 1)
    e.run('df', sleep = 1),
    #print e.stop_app_session('exit')
    e.stop_app_session('exit')
    e.run('ps -ef | grep sh')
    
    print '\n   -------- command with exceptions --------\n'
    action = [
        "cd ..",
        "pwd",
        {"cmd":"ls -l",
         "exception-with":["provision-target.lst"],
         "exception-without-all":["config.bcm", "rc.soc", "selinux", "ap_cfg.py"],
         "exception-without-any":["dispatcher", "ap_mgr", "script"],
         "on-exception":{"do":["df", "date"],
                         "msg":"ls -l : error"}
        },
        "version",
        {"cmd":"ls -l /var/spool/cron",
         "exception-without-any":["crontab", "\w+\s+\d+\s+[\d:]+"],
         "on-exception":{"msg":"tar error: rootfs.tar.gz extract incomplete"}
        },
        "uname"
    ]
    print "\n   ------- cmd list -----\n"
    for i in action:
        #print e.expect(i)
        print e.cmd(i)
    print "\n   ------- run -----\n"

    e.stop()

    # XorPlus Test
    print("\n--- XorPlus Test ---\n")

    #e = ap_task(mode=Mode.telnet)
    e.start()

    if e.ci.mode == Mode.shell:
        print e.start_app_session('/pica/bin/pica_sh', ['XorPlus>', 'XorPlus#'], run_only = False, app_cmd_prompt = ''),
    else:
        print e.cmd('/pica/bin/pica_sh'),
    e.run('show system os'),
    e.run('show version'),
    e.run('configure'),
    e.run('quit'),
    e.run('show system date'),
    e.run('show system serial-number'),
    e.run('show system fan'),
    e.run('show system uptime'),
    # try other methods
    print 'expect returns: %s' % str(e.expect('show version'))
    print 'extract returns: %s' % str(e.extract('show version', ': ([\d\.]+)'))
    print 'extract returns: %s' % str(e.extract('show version', '(\w+):(\w+):'))
    # match all
    r = e.extract_all('show system uptime', pattern='.*up\s+(\d+)\s+day*\s+(\d+):(\d+),')
    print r
    xorp_test(e)

    #if isinstance(e, telnet):
    if e.ci.mode == Mode.shell:
        print e.stop_app_session('quit')
    else:
        e.cmd('quit')
        
    '''
    if e.ci.mode == Mode.shell:
        app_session = e.app_session(['XorPlus>', 'XorPlus#'], run_only = False, app_cmd_prompt = '')
        app_session.start_session('/pica/bin/pica_sh')
        xorp_test(app_session)
        app_session.stop_session('quit')
    '''
   
    #ovs_test(e)
    e.stop()
    print '\n   -------- end of test --------\n'

def xorp_test(e):
    cmds = ["show version",
            "configure",
            "set vlans vlan-id 10",
            "commit", 
            "set vlans vlan-id 2010", 
            "commit",
            "set vlans vlan-id 2020",
            "commit",
            "set vlans vlan-id 10 l3-interface vlan-10",
            "commit",
            "set vlan-interface interface vlan-10 vif vlan-10 address 10.0.0.110 prefix-length 31",
            "commit",
            "set vlans vlan-id 2010 l3-interface vlan-2010",
            "set vlan-interface interface vlan-2010 vif vlan-2010 address 10.20.10.1 prefix-length 24",
            "set vlans vlan-id 2020 l3-interface vlan-2020",
            "set vlan-interface interface vlan-2020 vif vlan-2020 address 10.20.20.1 prefix-length 24",
            "commit",
            "show interface aggregate-ethernet ae1",                         
            "quit",
            "show system uptime"
        ]
    print "\n   ------- cmd list: xorp -----\n"
    for i in cmds:
        #print e.expect(i)
        print e.cmd(i)
    print "\n   ------- run: xorp -----\n"
    #e.run(cmds)

def ovs_test(e):
    cmds = ["ovs-vsctl --db=tcp:172.16.0.104:6633 add-br br0 -- set bridge br0 datapath_type=pronto",
            "ovs-vsctl --db=tcp:172.16.0.104:6633 set-controller br0 tcp:172.16.1.240:6633",
            "ovs-vsctl set Bridge br0 stp_enable=true",
            "ovs-vsctl --db=tcp:172.16.0.104:6633 add-port br0 ge-1/1/1 -- set interface ge-1/1/1 type=pronto",
            "ovs-vsctl --db=tcp:172.16.0.104:6633 add-port br0 ge-1/1/2 -- set interface ge-1/1/2 type=pronto"                   
        ]
    print "\n   ------- cmd list: ovs -----\n"
    for i in cmds:
        #print e.expect(i)
        print e.cmd(i)
    print "\n   ------- run: ovs -----\n"
    #e.run(cmds)

def test_lease():
    #ap = ap_task(echo = False)
    ap = ap_task()

    ap.start()    #ap.start_net()    
    ap.switch_info()
    # get tftp server IP address
    cmd = 'grep -a tftp-server-name /var/lib/dhcp/dhclient.eth0.leases | tail -1'
    tftpserver = ap.extract(cmd, 'tftp-server-name \"([\d\.]+)\";')
    if tftpserver != '':
        print 'cmd: %s' % cmd
        print 'server: %s' % tftpserver
    # get bootfile name
    cmd = 'grep -a bootfile-name /var/lib/dhcp/dhclient.eth0.leases | tail -1'
    bootfile = ap.extract(cmd, 'bootfile-name \"([a-zA-Z0-9_\./]+)\";')
    if bootfile != '':
        print 'cmd: %s' % cmd
        print 'bootfile: %s' % bootfile
    ap.stop()

def test_tftp():

    print("\n--- TFTP Test ---\n")
    e = ap_task(timeout = 5)
    #print e.start_app_session('tftp', ["#", "tftp>"], run_only = True),
    e.start_app_session('tftp', ["#", "tftp>"], run_only = True)
    e.run('?'),
    e.run('connect 10.1.0.42'),
    e.run('get test.txt'),
    e.run('put tmp/picascript.py'),
    e.run('put tmp/picacommand.py'),
    e.run('put tmp/ap_task.py'),
    e.run('put tmp/ap_dispatcher.py'),
    e.run('put tmp/ap_mgr.py'),
    e.run('put tmp/ap_cfg.py'),
    #print e.stop_app_session('quit')
    e.stop_app_session('quit')
    e.run('ps -ef | grep tftp'),

    e.run('date'),


# read file in JSON format, return a dictionary
def read(file):
    dict = {}
    fd = open(file, "r")
    data = fd.read()
    dict = json.loads(data)
    fd.close()

    return dict

def task_test():
    e = ap_task(mode=Mode.shell, timeout = 2)
    script = read('test.script')
    tasks = script['provision tasks']
    for task in list(tasks):
        print 'execute task: %s' % task
        e.do_task(tasks[task])
        
def boot_option_test():
    option = 3
    e = ap_task(mode=Mode.shell, timeout = 1)
    e.set_picos_start_option(option)    
    cmd = "grep picos_start /etc/picos/picos_start.conf"
    e.expect(cmd)
    cmd = "grep ovs_switch_ip_address /etc/picos/picos_start.conf"
    e.expect(cmd)
    cmd = "grep ovs_switch_gateway /etc/picos/picos_start.conf"
    e.expect(cmd)
    e.cmd('date')
    

if __name__ == '__main__':
    main()
    
