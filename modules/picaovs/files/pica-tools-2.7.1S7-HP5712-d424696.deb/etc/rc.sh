#!/bin/bash

#>/etc/mtab

. /etc/functions
. /etc/rc_hw.sh

BRAND_NAME=`grep BRAND_NAME /pica/etc/brand |awk -F= '{print $2}'`
PLATFORM_NAME=`grep PLATFORM_NAME /pica/etc/brand |awk -F= '{print $2}'`

mount_all_func()
{
    #mount /proc so "reboot" works
    #mount -t proc proc /proc
    #mount -t devpts devpts /dev/pts
    #mount -t sysfs sysfs /sys
    # TODO: check if had been mounted, don't use remount option if not mounted
    mount -o remount,rw,noatime /

    #mount ramdisk
    mke2fs /dev/ram0 > /dev/null 2>&1
    mount /dev/ram0 /tmp
}

create_ramdisk_dir()
{
    chown 0:1 /tmp
    chmod 777 /tmp
    # /tmp/log is used for syslog
    mkdir /tmp/log
    chown 0:1 /tmp/log
    chmod 775 /tmp/log
    #touch the default syslog output file
    touch /tmp/log/messages
    chown 0:1 /tmp/log/messages
    chmod 775 /tmp/log/messages
    if [ ! -f /var/log/messages ]; then
        touch /var/log/messages
    fi
    chown 0:1 /var/log/messages
    chmod 775 /var/log/messages

    touch /tmp/log/lastlog
    chown root:utmp /tmp/log/lastlog
    chmod 664 /tmp/log/lastlog
    if [ -f /var/log/lastlog ];then
        rm -fr /var/log/lastlog
    fi
    ln -s /tmp/log/lastlog /var/log/lastlog

    touch /tmp/log/wtmp
    if [ -f /var/log/wtmp ];then
        rm -fr /var/log/wtmp
    fi
    ln -s /tmp/log/wtmp /var/log/wtmp

    #/tmp/snmp is used for other module to send date to snmp
    mkdir /tmp/snmp
    chown 0:1 /tmp/snmp
    chmod 775 /tmp/snmp

    #/tmp/system is used for system file
    mkdir /tmp/system
    chown 0:1 /tmp/system
    chmod 777 /tmp/system

    #/tmp/run is used for system run status
    mkdir /tmp/run
    chown 0:1 /tmp/run
    chmod 777 /tmp/run
    #touch some tmp file to let the /var/log and /var/run to link*/
    #touch /tmp/run/crond.pid
    #touch /tmp/run/syslogd.pid
    touch /tmp/run/i2c-lock
    chown 0:1 /tmp/run/i2c-lock
    chmod 777 /tmp/run/i2c-lock

    #touch /tmp/run/wtmp
    #ln -s /tmp/wtmp /var/log/wtmp
    ln -s /tmp/run /var/run
    #/tmp/run/crontab is used for crontab
    mkdir /tmp/run/crontab
    chown 0:1 /tmp/run/crontab

    if [ -e /var/spool/cron ];then
        rm -fr /var/spool/cron
    fi

    ln -s /tmp/run/crontab /var/spool/cron

    mkdir /tmp/run/crontab/crontabs
    chgrp crontab /tmp/run/crontab/crontabs

    #lighttpd log dir
    mkdir -p /tmp/log/lighttpd
    chmod 755 /tmp/log/lighttpd

}

recover_home_dir()
{
    chmod 775 /home
    if [ ! -d /home/admin ];then
        mkdir /home/admin
    fi
    if [ ! -d /home/operator ];then
        mkdir /home/operator
    fi
    chown root:1 /root
    chown admin:1 /home/admin
    chown operator:1 /home/operator
}

mkdir_mnt()
{
    #mkdir -p ${DEFAULT_MNT}
    mkdir -p ${STORAGE_MNT}
}

upgrade_pica_image()
{
    # upgrade pica package if the pica.tar.gz exist,
    # which will be removed after the upgrading is finished
    if [ -f /cftmp/pica.tar.gz ]; then
        # check if the md5 exists
        if [ -f /cftmp/pica.tar.gz.md5 ]; then
            upgrade_logger "${PLATFORM_NAME} Upgrade process: check pica image MD5!"
		    cd /cftmp
            md5sum -c pica.tar.gz.md5
            if [ $? -eq 0 ]; then
                upgrade_logger "${PLATFORM_NAME} Upgrade process: MD5 correct"
            else
                upgrade_logger "${PLATFORM_NAME} Upgrade process: MD5 checking FAILED"
                upgrade_logger "${PLATFORM_NAME} Upgrade process: [FAIL] Restarting with previous image"
                return 0
            fi
        else
            upgrade_logger "${PLATFORM_NAME} Upgrade process: ${BRAND_NAME} package MD5 file not found!"
		    cd /cftmp/
            md5sum pica.tar.gz
            upgrade_logger "${PLATFORM_NAME} Upgrade process: Make sure pica package MD5 is correct!"
        fi

        sleep 3
        #rm -rf /pica/etc/templates/
        cd /
        tar zxvf /cftmp/pica.tar.gz
        rm /cftmp/pica.tar.gz
        upgrade_logger "${PLATFORM_NAME} Upgrade process: wait a minute, sync the data to disk ..."
        sync
        upgrade_logger "${PLATFORM_NAME} Upgrade process: ${BRAND_NAME} package upgrading finished. Restart now ..."
        reboot
    fi
}

# upgrade the system if the rootfs.tar.gz exist,
# which will be removed after the upgrading is finished
upgrade_system_image()
{
    if [ -f /cftmp/rootfs.tar.gz ]; then
        rm_upgrade_log
        upgrade_logger "${PLATFORM_NAME} Upgrade process: starting."
        # check if partition 2 is available
        status=$(get_fs_status "secondary" "/etc/picos")
        if [[ "${status}" != "up-to-date" ]]; then
            if [[ "${status}" != "ok" ]]; then
                upgrade_logger "${PLATFORM_NAME} Upgrade process: file system status checking FAILED"
                upgrade_logger "${PLATFORM_NAME} Upgrade process: [FAIL] Restarting with previous image"
                return 1
            fi
        fi
        status=$(backup_e2fsck)
        if [[ ${status} -ne 0 ]]; then
            upgrade_logger "${PLATFORM_NAME} Upgrade process: file system checking FAILED"
            upgrade_logger "${PLATFORM_NAME} Upgrade process: [FAIL] Restarting with previous image"
            return 1
        fi

        #check partition size
        partition_size_check
        if [ $? -ne 0 ]; then
            upgrade_logger "${PLATFORM_NAME} Upgrade process: partition size checking FAILED"
            upgrade_logger "${PLATFORM_NAME} Upgrade process: [FAIL] Restarting with previous image"
            return 1
        fi

        if [ -f /pica/config/pica_startup.boot ]; then
            res=`grep "Has Deprecated Node" /pica/config/pica_startup.boot | grep 1 | wc -l`
            if [ $res -ne 0 ]; then
                upgrade_logger "${PLATFORM_NAME} Upgrade process: configuration file /pica/config/pica_startup.boot has deprecated node"
                upgrade_logger "${PLATFORM_NAME} Upgrade process: configuration file checking FAILED"
                upgrade_logger "${PLATFORM_NAME} Upgrade process: [FAIL] Restarting with previous image"
                return 1
            fi
        fi

        # check if the md5 exists
        if [ -f /cftmp/rootfs.tar.gz.md5 ]; then
            upgrade_logger "${PLATFORM_NAME} Upgrade process: checking image MD5!"
            cd /cftmp/
            md5sum -c rootfs.tar.gz.md5
            if [ $? -eq 0 ]; then
                upgrade_logger "${PLATFORM_NAME} Upgrade process: image MD5 correct"
                #rm -rf /pica/etc/templates/
            else
                upgrade_logger "${PLATFORM_NAME} Upgrade process: MD5 checking FAILED"
                upgrade_logger "${PLATFORM_NAME} Upgrade process: [FAIL] Restarting with previous image"
                return 0
            fi
#       else
#           echo "image MD5 file not found!"
#           cd /cftmp
#           echo "image MD5 information:"
#           md5sum rootfs.tar.gz
#           echo "Make sure the image MD5 is correct!"
#           sleep 3

            #rm -rf /pica/etc/templates/
        fi
        cd /
        upgrade_logger "${PLATFORM_NAME} Upgrade process: ${BRAND_NAME} ${PLATFORM_NAME} image upgrade"
        upgrade_logger " "
        sleep 2
        mount ${BACKUP_STORAGE_DEV} /mnt/sd_card
        if [ $? -ne 0 ]; then
            upgrade_logger "${PLATFORM_NAME} Upgrade process: mount partition 2 FAILED"
            upgrade_logger "${PLATFORM_NAME} Upgrade process: [FAIL] Restarting with previous image"
            return 1
        fi
        cd /mnt/sd_card
        sleep 2
        pivot_root . mnt/usb
        sleep 3
        #exec chroot . sh <dev/console >dev/console 2>&1
        exec chroot . sh -c 'date; exec /mnt/usb/etc/p1upgrade.sh' <dev/console >dev/console 2>&1
        upgrade_logger "${PLATFORM_NAME} Upgrade process: Image upgrading finished. Restart now ..."
        upgrade_logger " "
        reboot
    fi
}

create_standard_io()
{
    # to provide standard i/o files as links
    rm -f /dev/stdin
    rm -f /dev/stdout
    rm -f /dev/stderr
    ln -s /proc/self/fd/0 /dev/stdin
    ln -s /proc/self/fd/1 /dev/stdout
    ln -s /proc/self/fd/2 /dev/stderr
}

network_up()
{
    ifconfig lo 127.0.0.1 up
}

create_picaos_dir()
{
    # If ${STORAGE_MNT} is not mounted, create the log dir in rootfs
    mkdir -p ${LOG_DIR}

    mkdir -p ${CONFIG_DIR}
    chown 0:1 ${CONFIG_DIR}
    #chmod 775 ${CONFIG_DIR}
    chmod a+w ${CONFIG_DIR}
    if [ -d ${PICA_DIR}/bin/shell ];then
        chmod +x ${PICA_DIR}/bin/shell/*.sh
    fi
}

update_system_config()
{
    #change permission; TODO:make better permission plan later
    chmod 755 /etc/radvd.conf
    #clear radvd.conf
    sed -i "/# begin for interface/,/# end for interface/d" /etc/radvd.conf
    #enable core dump
    ulimit -c unlimited
    echo 1 > /proc/sys/kernel/core_uses_pid
    # enlarge file numbers
    #ulimit -n 8192
    mkdir -p ${CORE_DIR}
    echo "${CORE_DIR}/core.%e.pid_%p.uid_%u.sig_%s" > /proc/sys/kernel/core_pattern

    #sysctl
    #use /etc/sysctl.conf by default, we avoid using it by doing it here.
    sysctl -w net.netfilter.nf_conntrack_acct=1
    sysctl -w net.ipv6.conf.all.forwarding=1

    #enable ip forward
    echo 1 > /proc/sys/net/ipv4/ip_forward
    echo 1 > /proc/sys/net/ipv6/conf/default/forwarding
    #disable ip forwarding on eth0/eth1
    echo 0 > /proc/sys/net/ipv4/conf/eth0/forwarding
    echo 0 > /proc/sys/net/ipv6/conf/eth0/forwarding
    [ -d /proc/sys/net/ipv4/conf/eth1 ] && echo 0 > /proc/sys/net/ipv4/conf/eth1/forwarding
    [ -d /proc/sys/net/ipv4/conf/eth1 ] && echo 0 > /proc/sys/net/ipv6/conf/eth1/forwarding
    #enlarge arp table
    echo 512 > /proc/sys/net/ipv4/neigh/default/gc_thresh1
    echo 2048 > /proc/sys/net/ipv4/neigh/default/gc_thresh2
    echo 4096 > /proc/sys/net/ipv4/neigh/default/gc_thresh3
    #change arp time
    echo 60 > /proc/sys/net/ipv4/neigh/default/gc_interval
    echo 120 > /proc/sys/net/ipv4/neigh/default/gc_stale_time
    echo 1200 > /proc/sys/net/ipv4/neigh/default/base_reachable_time
    #disable proxy arp
    echo 0 > /proc/sys/net/ipv4/conf/default/proxy_arp
    #disable proxy ndp
    echo 0 > /proc/sys/net/ipv6/conf/default/proxy_ndp
    #echo 0 > /proc/sys/net/ipv6/conf/eth0/proxy_ndp
    #[ -d /proc/sys/net/ipv4/conf/eth1 ] && echo 0 > /proc/sys/net/ipv6/conf/eth1/proxy_ndp
    #enable arp accept
    echo 1 > /proc/sys/net/ipv4/conf/all/arp_accept
    #Set maximum join limit
    echo 2048 > /proc/sys/net/ipv4/igmp_max_memberships

    #enlarge neigh table
    echo 512 > /proc/sys/net/ipv6/neigh/default/gc_thresh1
    echo 2048 > /proc/sys/net/ipv6/neigh/default/gc_thresh2
    echo 4096 > /proc/sys/net/ipv6/neigh/default/gc_thresh3
    #change neigh time
    echo 60 > /proc/sys/net/ipv6/neigh/default/gc_interval
    echo 120 > /proc/sys/net/ipv6/neigh/default/gc_stale_time
    echo 1200000 > /proc/sys/net/ipv6/neigh/default/base_reachable_time_ms

    #enlarge route table
    echo 8192 > /proc/sys/net/ipv6/route/gc_thresh
    echo 65536 > /proc/sys/net/ipv6/route/max_size

    echo 2 > /proc/sys/net/ipv4/conf/all/arp_announce

    #For sshd
    chmod 600 /var/empty /etc/ssh/ssh_host_dsa_key /etc/ssh/ssh_host_rsa_key
    chown root:root /var/empty /etc/ssh/ssh_host_dsa_key /etc/ssh/ssh_host_rsa_key

    #delete xorp and ovs pid file
    rm -fr /var/run/xorp_rtrmgr.pid
    rm -fr /ovs/var/run/openvswitch/ovs-vswitchd.pid

    ldconfig

    check_reset_system_config
    if [ $? -eq 1 ]; then
        #Only for prompt
        hostname XorPlus
        rm /etc/ntp-server
        touch /etc/ntp-server
        chmod 775 /etc/ntp-server
        #delete announcement in motd
        echo "" >/etc/motd
    fi
}

start_system_service()
{
    check_reset_system_config
    if [ $? -ne 1 ]; then
        /etc/init.d/rsyslog start
        /etc/init.d/cron start
        return 0
    fi
    #disable tac, radius and enable local auth for root to auto login on console.
    if [ -f /pica/bin/shell/tacacs_disable.sh ];then
        /pica/bin/shell/tacacs_disable.sh true
    fi
    if [ -f /pica/bin/shell/radius_disable.sh ];then
        /pica/bin/shell/radius_disable.sh true
    fi
    sed -i 's/\(^#*\)\(.*\)pam_unix\(.*\)/\2pam_unix\3/g' /etc/pam.d/common-auth
    #disalbe root login from telnet and ssh
    sed -i "s/^PermitRootLogin.*/PermitRootLogin no/" /etc/ssh/sshd_config
    sed -i 's/\(^#*\)auth\(.*\)new_authtok_reqd\(.*\)pam_securetty\(.*\)/auth\2new_authtok_reqd\3pam_securetty\4/g' /etc/pam.d/login
    #set telnet connect instance to 15
    sed -i "s/instances.*/instances = 15/" /etc/xinetd.conf
    #disable telnet
    sed -i "s/disable.*/disable = yes/" /etc/xinetd.d/telnet
    #recover system syslog setting
    sed -i 's/\(.*\)mychannel\(.*\)messages\(.*\)/\1mychannel,\/tmp\/log\/messages\3/g' /etc/rsyslog.conf
    sed -i "s/^*.*.*@.*/*.* @127.0.0.1/g" /etc/rsyslog.conf
    echo > /etc/rsyslog.d/pica8.conf
    #start system service
    /etc/init.d/rsyslog start
    /etc/init.d/cron start
    /etc/init.d/ssh start
    #/etc/init.d/xinetd start
}

# auto-provisioning: check upgrade requests
pica_auto_provision()
{
    echo "${BRAND_NAME} Auto Provisioning Tool - checking updates ...."
    exec /usr/local/bin/ztp.sh
    #cd /usr/lib/python2.7/dist-packages/pica8
    #python ap_mgr.py
    #python ap_cfg.py
    #cd /
}

#convert PicOS configuration file
pica_convert_configuration_file()
{
    ovs_schema=/ovs/share/openvswitch/vswitch.ovsschema
    # check p2 status
    status=$(get_fs_status "secondary" /etc/picos/)
    if [[ "${status}" == "ready-clean" ]]; then
        if [ -f $PICAOS_CONFIG_FILE ]; then
            picos_configuration_file_praser OVS
            if [ ! -z $ovs_database_file ];then
                if [ -f $ovs_database_file -a -f $ovs_schema ];then
                    /ovs/bin/ovsdb-tool convert $ovs_database_file $ovs_schema $ovs_database_file.new
                    mv $ovs_database_file.new $ovs_database_file
                fi
            fi
            if [ ! -z $ovs_inventory_database_file ] && [ ! -z $inventory_schema ];then
                if [ -f $ovs_inventory_database_file -a -f $inventory_schema ];then
                    /ovs/bin/ovsdb-tool convert $ovs_inventory_database_file $inventory_schema $ovs_inventory_database_file.new
                    mv $ovs_inventory_database_file.new $ovs_inventory_database_file
                fi
            fi
            #if [ ! -z $ovs_function_database_file -a ! -z $function_schema ];then
            if [ ! -z $ovs_function_database_file ] && [ ! -z $function_schema ];then
                if [ -f $ovs_function_database_file -a -f $function_schema ];then
                    /ovs/bin/ovsdb-tool convert $ovs_function_database_file $function_schema $ovs_function_database_file.new
                    mv $ovs_function_database_file.new $ovs_function_database_file
                fi
            fi
        fi
    fi

    if [ ! -f $PICAOS_CONFIG_FILE ]; then
        return 0
    fi
    #the default vaule
    picos_start=xorpplus
    xorpplus_rtrmgr_verbose=""
    xorpplus_log_facility=local0
    xorpplus_finder_client_address=127.0.0.1
    xorpplis_finder_server_address=127.0.0.1
    ovs_database_file=/ovs/ovs-vswitchd.conf.db
    ovs_inband_database_file=/ovs/inband.conf.db
    ovs_inventory_database_file=/tmp/inventory.conf.db
    inventory_schema=/ovs/share/openvswitch/inventory.ovsschema
    ovs_function_database_file=/ovs/function.conf.db
    function_schema=/ovs/share/openvswitch/function.ovsschema
    ovs_db_sock_file=/ovs/var/run/openvswitch/db.sock
    ovs_invd_file=/ovs/share/openvswitch/scripts/ovs-invd
    ovs_invd_python_path=/ovs/share/openvswitch/python
    ovs_db_manager=Open_vSwitch,Manager,target
    ovs_switch_ip_address=127.0.0.1
    ovs_switch_ip_netmask=255.255.255.0
    ovs_switch_gateway_ip=127.0.0.1
    ovs_switch_tcp_port=6640
    ovs_host_name=${PLATFORM_NAME}-OVS
    ovs_use_dhcp=false
    ovs_enable_lighttpd=false
    ztp_disable=false
    otp_disable=false

    #change host name 
    sed -i "/ovs_host_name=/s/PicOS-OVS/${ovs_host_name}/" $PICAOS_CONFIG_FILE
    #read old configuration file
    ini_cfg_praser PICOS "$PICAOS_CONFIG_FILE"
    ini_cfg_praser XORPPLUS "$PICAOS_CONFIG_FILE"
    ini_cfg_praser OVS "$PICAOS_CONFIG_FILE"
    ini_cfg_praser ZTP "$PICAOS_CONFIG_FILE"

    if [ 0 -eq `grep ${ovs_host_name} /etc/hosts | wc -l` ]; then
        echo "127.0.0.1  ${ovs_host_name}" >> /etc/hosts
    fi

    #generate the new configuration file
    echo "# configuration file for PicaOS" > $PICAOS_CONFIG_FILE
    echo "" >> $PICAOS_CONFIG_FILE
    echo "[PICOS]" >> $PICAOS_CONFIG_FILE
    echo "picos_start=$picos_start" >> $PICAOS_CONFIG_FILE
    echo "" >> $PICAOS_CONFIG_FILE
    echo "[XORPPLUS]" >> $PICAOS_CONFIG_FILE
    echo "xorpplus_rtrmgr_verbose=$xorpplus_rtrmgr_verbose" >> $PICAOS_CONFIG_FILE
    echo "xorpplus_log_facility=$xorpplus_log_facility" >> $PICAOS_CONFIG_FILE
    echo "xorpplus_finder_client_address=$xorpplus_finder_client_address" >> $PICAOS_CONFIG_FILE
    echo "xorpplis_finder_server_address=$xorpplis_finder_server_address" >> $PICAOS_CONFIG_FILE
    echo "" >> $PICAOS_CONFIG_FILE
    echo "[OVS]" >> $PICAOS_CONFIG_FILE
    echo "ovs_database_file=$ovs_database_file" >> $PICAOS_CONFIG_FILE
    echo "ovs_inband_database_file=$ovs_inband_database_file" >> $PICAOS_CONFIG_FILE
    echo "ovs_inventory_database_file=$ovs_inventory_database_file" >> $PICAOS_CONFIG_FILE
    echo "inventory_schema=$inventory_schema" >> $PICAOS_CONFIG_FILE
    echo "ovs_function_database_file=$ovs_function_database_file" >> $PICAOS_CONFIG_FILE
    echo "function_schema=$function_schema" >> $PICAOS_CONFIG_FILE
    echo "ovs_db_sock_file=$ovs_db_sock_file" >> $PICAOS_CONFIG_FILE
    echo "ovs_invd_file=$ovs_invd_file" >> $PICAOS_CONFIG_FILE
    echo "ovs_invd_python_path=$ovs_invd_python_path" >> $PICAOS_CONFIG_FILE
    echo "ovs_db_manager=$ovs_db_manager" >> $PICAOS_CONFIG_FILE
    echo "ovs_switch_ip_address=$ovs_switch_ip_address" >> $PICAOS_CONFIG_FILE
    echo "ovs_switch_ip_netmask=$ovs_switch_ip_netmask" >> $PICAOS_CONFIG_FILE
    echo "ovs_switch_gateway_ip=$ovs_switch_gateway_ip" >> $PICAOS_CONFIG_FILE
    echo "ovs_switch_tcp_port=$ovs_switch_tcp_port" >> $PICAOS_CONFIG_FILE
    echo "ovs_host_name=$ovs_host_name" >> $PICAOS_CONFIG_FILE
    echo "ovs_use_dhcp=$ovs_use_dhcp" >> $PICAOS_CONFIG_FILE
    echo "ovs_enable_lighttpd=$ovs_enable_lighttpd" >> $PICAOS_CONFIG_FILE
    echo "" >> $PICAOS_CONFIG_FILE
    echo "[ZTP]" >> $PICAOS_CONFIG_FILE
    echo "ztp_disable=$ztp_disable" >> $PICAOS_CONFIG_FILE
    echo "otp_disable=$otp_disable" >> $PICAOS_CONFIG_FILE

}

auto_install_license()
{
    if [ -f /cftmp/picos.lic -a -f /usr/sbin/license ];then
        /usr/sbin/license -i /cftmp/picos.lic
    fi
}

copy_config_files_for_as4610()
{

    lcmgr_type=`cat /sys/class/cpld/product_id`
    #echo ${lcmgr_type}
    #echo ${lcmgr_type:2:4}
    if test "${lcmgr_type:2:4}" == "4610"; then
        res=${lcmgr_type:7:2}
        #echo ${res}

        file_name="plc_cfg_bcm.soc.${res}p"
        #echo "file=${file_name}"
        #echo "files=/pica/bin/lcmgr/${file_name}"
        if test -f /pica/bin/lcmgr/"${file_name}"; then
            cp /pica/bin/lcmgr/"${file_name}" /pica/bin/lcmgr/plc_cfg_bcm.soc
        fi
        
        file_name="plc_cfg_pica.soc.${res}p"
        #echo "file=${file_name}"
        #echo "files=/pica/bin/lcmgr/${file_name}"
        if test -f /pica/bin/lcmgr/"${file_name}"; then
            cp /pica/bin/lcmgr/"${file_name}" /pica/bin/lcmgr/plc_cfg_pica.soc
        fi
        
        file_name="plc_cfg_portmap.soc.${res}p"
        #echo "file=${file_name}"
        #echo "files=/pica/bin/lcmgr/${file_name}"
        if test -f /pica/bin/lcmgr/"${file_name}"; then
            cp /pica/bin/lcmgr/"${file_name}" /pica/bin/lcmgr/plc_cfg_portmap.soc
        fi
        
        file_name="plc_init_bcm.soc.${res}p"
        #echo "file=${file_name}"
        #echo "files=/pica/bin/lcmgr/${file_name}"
        if test -f /pica/bin/lcmgr/"${file_name}"; then
            cp /pica/bin/lcmgr/"${file_name}" /pica/bin/lcmgr/plc_init_bcm.soc
        fi
        
        file_name="ipfix.tp.${res}p"
        #echo "file=${file_name}"
        #echo "files=/pica/etc/templates/${file_name}"
        if test -f /pica/etc/templates/"${file_name}"; then
            cp /pica/etc/templates/"${file_name}" /pica/etc/templates/ipfix.tp
        fi
        
        file_name="sif.tp.${res}p"
        #echo "file=${file_name}"
        #echo "files=/pica/etc/templates/${file_name}"
        if test -f /pica/etc/templates/"${file_name}"; then
            cp /pica/etc/templates/"${file_name}" /pica/etc/templates/sif.tp
        fi
        
        file_name="pica_default.boot.${res}p"
        #echo "file=${file_name}"
        #echo "files=/pica/bin/${file_name}"
        if test -f /pica/bin/"${file_name}"; then
            cp /pica/bin/"${file_name}" /pica/bin/pica_default.boot
        fi
        file_name="pica_dev_info.conf.${res}p"                             
        #echo "file=${file_name}"                                            
        #echo "files=/etc/${file_name}"                              
        if test -f /etc/"${file_name}"; then                         
            cp /etc/"${file_name}" /etc/pica_dev_info.conf
        fi                                                                   
    fi
}

#mount all file system
#mount_all_func

#create ramdisk dir
create_ramdisk_dir

#recover home dir
recover_home_dir

#create dev node
create_dev_node

#insmod module
install_kernel_module

#create dir for mount
mkdir_mnt

#some hardware-related work
do_other_hw_dep_work

#convert picos configuation file if needed
pica_convert_configuration_file

#upgrade bacpup image
/etc/p2upgrade.sh

#upgrade system image
upgrade_system_image

#upgrade pica image
upgrade_pica_image

#provide standard i/o files as links
create_standard_io

#enable network
network_up

#create dir for picaos
create_picaos_dir

#update system configuration
update_system_config

#start system service
start_system_service

#install license
auto_install_license

#auto provision
pica_auto_provision

