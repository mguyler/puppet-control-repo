#!/bin/bash

# enable color support of ls and also add handy aliases
if [ -x /usr/bin/dircolors ]; then
    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"
    alias ls='ls --color=auto'
    #alias dir='dir --color=auto'
    #alias vdir='vdir --color=auto'

    alias grep='grep --color=auto'
    alias fgrep='fgrep --color=auto'
    alias egrep='egrep --color=auto'
fi

# some more ls aliases
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'

export boot_menu_dir="/pica/config"
export boot_menu_file="/pica/config/boot.lst"
export XORP_FINDER_CLIENT_ADDRESS=127.0.0.1
export XORP_FINDER_SERVER_ADDRESS=127.0.0.1

ulimit -c unlimited

#Enabling tab-completion
_complete_sudo()
{
  if [ "$COMP_CWORD" -ge '2' ]; then
    cur="${COMP_WORDS[$COMP_CWORD]}"
    compopt -o filenames
    COMPREPLY=( $(compgen -f -- "$cur") )
  else
    local PATH=$PATH:/usr/local/sbin:/usr/sbin:/sbin
    COMPREPLY=( $(compgen -c -- "$2") )
  fi
}
complete -F _complete_sudo sudo

#ttyname=`tty`

#if [[ x"$ttyname" == x"/dev/ttyS0" ]] ; then
#    stty -F /dev/ttyS0  rows 45
#    stty -F /dev/ttyS0  cols 114
#fi

#for i in `groups`
#do
#    if [ $i == "ovs" ]; then
#        export PATH=$PATH:/ovs/sbin
#        break
#    fi
#done

if [ -f $HOME/.bashrc ]; then
    . $HOME/.bashrc
fi

