#!/bin/bash

. /etc/functions

PLATFORM_NAME=`grep PLATFORM_NAME /pica/etc/brand |awk -F= '{print $2}'`

UPGRADE_LOG_FILE=/mnt/usb/cftmp/upgrade.log

# to do:
#    - dynamic create p2files.lst: usr/lib
# in extracting partition image in rc_ap2:
#   build_p2_image "/mnt/sd_card" "/mnt/sd_card/cftmp/p2" "/mnt/sd_card/usr/lib/python2.7/dist-packages/pica8/p2files.lst" 
# after partition system starts:
#   build_p2_image "" "/cftmp/p2" "/usr/lib/python2.7/dist-packages/pica8/p2files.lst"

umount_partition1()
{
    mount -t proc proc /proc
    sleep 2
    umount /mnt/usb/sys
    umount /mnt/usb/proc
    umount /mnt/usb/run/lock
    umount /mnt/usb/run/shm
    umount /mnt/usb/run
    umount /mnt/usb/tmp
    sleep 2
    umount /mnt/usb/dev/pts > /dev/null 2>&1
}

# backup list of files and directories in a tar file
# backup_files "./etc/picos/backup_files.lst" "./cftmp/backup.tar.gz" 
backup_files()
{
    # if any files to backup 
    if [ $1 = "" ]; then
        return 1
    elif [ ! -f $1 ]; then
        return 1
    fi

    # where to backup
    dst=$(dirname $2)
    if [ ! -d $dst ]; then
        mkdir -p $dst
    fi

    #echo "upgrade: backup files listed in $1 ..."
    filelist=`cat $1 | sed 's#^/#./#' | grep -E -v ^#`
    tar -zcvf $2 $filelist > /dev/null
    return 0
}

# restore list of files and directories from a tar file
# restore_files "./cftmp/backup.tar.gz" "."
restore_files()
{
    # Directory where backup kept
    if [ ! -f $1 ]; then
        upgrade_logger "${PLATFORM_NAME} Upgrade process: restore - file not exist: ${1} "
    fi

    #echo "restore - from file: ${1} ..."
    TAR=`which tar`
    $TAR -zxvf $1 -C $2 > /dev/null
}


save_environment()
{
    cp ./usr/lib/python2.7/dist-packages/pica8/provision-target.lst ./cftmp/provision-target.lst.tmp
    if [ -f ./pica/config/pica_startup.boot ];then
        tar -zcvf ./cftmp/config.tar.gz ./pica/config/pica_startup.boot
    fi
    cp -fr ./etc/picos/picos_start.conf ./cftmp/picos_start.conf.tmp
    if [ -f ./ovs/ovs-vswitchd.conf.db ]; then
        cp ./ovs/ovs-vswitchd.conf.db ./cftmp/ovs-vswitchd.conf.db.tmp
    fi
    if [ -f ./ovs/function.conf.db ]; then
        cp ./ovs/function.conf.db ./cftmp/function.conf.db.tmp
    fi
    if [ -d ./ovs/var/lib/openvswitch/pki ]; then 
        cp ./ovs/var/lib/openvswitch/pki ./cftmp/pki.tmp -rf
    fi
    if [ -f ./etc/picos/switch-public.key ]; then
        cp  ./etc/picos/switch-public.key ./cftmp/switch-public.key.tmp
    fi
    if [ -f ./etc/picos/pica.lic ]; then
        cp  ./etc/picos/pica.lic ./cftmp/pica.lic.tmp
    fi
    if [ -f ./etc/picos/license.conf ]; then
        cp ./etc/picos/license.conf ./cftmp/license.conf.tmp
    fi
    #cp ./var/lib/dhcp/dhclient.leases ./cftmp/dhclient.leases.tmp
    if [ -f ./etc/picos/fs_status ]; then
        cp ./etc/picos/fs_status ./cftmp/fs_status.tmp
    else
        echo "secondary: new" > ./cftmp/fs_status.tmp
    fi

    # backup customer defined files
    if [ -f ./etc/picos/backup_files.lst ]; then
        rm -fr ./cftmp/backup.tar.gz
        upgrade_logger "${PLATFORM_NAME} Upgrade process: backup files listed in /etc/picos/backup_files.lst"
        backup_files ./etc/picos/backup_files.lst ./cftmp/backup.tar.gz
    fi
}

restore_environment()
{
    mv ./cftmp/provision-target.lst.tmp ./usr/lib/python2.7/dist-packages/pica8/provision-target.lst
    if [ -f ./cftmp/config.tar.gz ];then
        tar -zxvf ./cftmp/config.tar.gz
        rm -fr ./cftmp/config.tar.gz
    fi
    mv -f ./cftmp/picos_start.conf.tmp ./etc/picos/picos_start.conf
    if [ -f ./cftmp/ovs-vswitchd.conf.db.tmp ]; then
        mv ./cftmp/ovs-vswitchd.conf.db.tmp ./ovs/ovs-vswitchd.conf.db
    fi
    if [ -f ./cftmp/function.conf.db.tmp ]; then
        mv ./cftmp/function.conf.db.tmp ./ovs/function.conf.db
    fi
    if [ -d ./cftmp/pki.tmp ]; then
        rm ./ovs/var/lib/openvswitch/pki -rf
        mv ./cftmp/pki.tmp ./ovs/var/lib/openvswitch/pki
    fi
    if [ -f ./cftmp/switch-public.key.tmp ]; then
        mv ./cftmp/switch-public.key.tmp ./etc/picos/switch-public.key
    fi
    if [ -f ./cftmp/pica.lic.tmp ]; then
        mv ./cftmp/pica.lic.tmp ./etc/picos/pica.lic
    fi
    if [ -f ./cftmp/license.conf.tmp ]; then
        mv ./cftmp/license.conf.tmp ./etc/picos/license.conf
    fi
    #mv ./cftmp/dhclient.leases.tmp ./var/lib/dhcp/dhclient.leases
    mv ./cftmp/fs_status.tmp ./etc/picos/fs_status
   
    # restore customer defined files
    if [ -f ./cftmp/backup.tar.gz ]; then
        upgrade_logger "${PLATFORM_NAME} Upgrade process: restore backup files"
        restore_files "./cftmp/backup.tar.gz" "."
        rm -fr ./cftmp/backup.tar.gz
    fi 
}

# umount old file system
umount_partition1
sleep 2

cd /mnt/usb

# save environment
save_environment

ls |grep -v cftmp|xargs rm -fr
mv ./cftmp/rootfs.tar.gz .
sync
sleep 2

# extract partition 1 file system
tar -xzvf rootfs.tar.gz

# restore environment
restore_environment

upgrade_logger "${PLATFORM_NAME} Upgrade process: wait a minute, sync the data to disk"
sync
rm rootfs.tar.gz
sleep 2
upgrade_logger " "
sync

# build 2nd partition image if os version changes
upgrade_logger "${PLATFORM_NAME} Upgrade process: building new partition 2 image ..."
build_partition2_image "." "./cftmp/p2" "./etc/picos/p2files.lst"
# mark partition 2 as ready with clean image
set_fs_status "secondary" "./etc/picos" "ready-clean"

if [ -f /boot/rootfs.ext2.gz.uboot ]; then
    cp /boot/rootfs.ext2.gz.uboot ./cftmp/p2/boot/
fi

upgrade_logger "${PLATFORM_NAME} Upgrade process: new partition 2 image ready"

upgrade_logger "${PLATFORM_NAME} Upgrade process: Image upgrading finished. Restart now ..."
upgrade_logger " "
reboot
