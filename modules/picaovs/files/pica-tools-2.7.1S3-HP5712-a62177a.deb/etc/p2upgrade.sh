#!/bin/bash

. /etc/functions

PLATFORM_NAME=`grep PLATFORM_NAME /pica/etc/brand |awk -F= '{print $2}'`

# to do:
#    - dynamic create p2files.lst: usr/lib
# in extracting partition image in rc_ap2:
#   build_p2_image "/mnt/sd_card" "/mnt/sd_card/cftmp/p2" "/mnt/sd_card/usr/lib/python2.7/dist-packages/pica8/p2files.lst" 
# after partition system starts:
#   build_p2_image "" "/cftmp/p2" "/usr/lib/python2.7/dist-packages/pica8/p2files.lst"

# this is called after p1 starts
#   update_partition2 "/dev/hda2" "/cftmp/p2" "/etc/picos" 
update_partition2() {
    device=$1
    source=$2
    path=$3
    
    upgrade_logger "${PLATFORM_NAME} Upgrade process: checking partition 2"
    
    # does partition 2 exist
    if ! [ -b "$1" ]; then
        # single partition
        upgrade_logger "${PLATFORM_NAME} Upgrade process: partition 2 does not exist"
        return 0
    fi

    # check p2 status
    status=$(get_fs_status "secondary" ${path})
    if [[ "${status}" == "up-to-date" ]]; then
        upgrade_logger "${PLATFORM_NAME} Upgrade process: partition 2 file system is ok"
        return 0
    fi
    if [[ "${status}" == "ok" ]]; then
        upgrade_logger "${PLATFORM_NAME} Upgrade process: partition 2 file system is ok"
        return 0
    fi

    check_status=$(backup_e2fsck)
    if [[ ${check_status} -ne 0 ]]; then
        upgrade_logger "${PLATFORM_NAME} Upgrade process: Partition 2 file system checking fail"
        return 1
    fi

    #check partition size
    partition_size_check
    if [ $? -ne 0 ]; then
        upgrade_logger "${PLATFORM_NAME} Upgrade process: partition size checking fail"
        return 1
    fi

    # mount partition 2
    umount /mnt/sd_card > /dev/null 2>&1
    mount $1 /mnt/sd_card
    if [ $? -ne 0 ]; then
        upgrade_logger "${PLATFORM_NAME} Upgrade process: Fail to mount partition 2"
        return 1
    fi

    # do we have a clean partition 2 image
    if [[ "$status" == "ready-clean" ]]; then
        # apply this clean image to partition 2
        upgrade_logger "${PLATFORM_NAME} Upgrade process: cleaning up partition 2 ..."
        rm -rf /mnt/sd_card/*
        sync
        upgrade_logger "${PLATFORM_NAME} Upgrade process: updating partition 2 file system"
        cp -ar ${source}/* /mnt/sd_card
        sync
        umount /mnt/sd_card
        rm -rf ${source}
        sync
        set_fs_status "secondary" ${path} "up-to-date"
        upgrade_logger "${PLATFORM_NAME} Upgrade process: partition 2 file system updated"
        return 0
    fi

    # do we have partition 2 image
    if [[ "$status" != "ready" ]]; then
        # build p2 image
        upgrade_logger "${PLATFORM_NAME} Upgrade process: basic system checking ..."
        basic_command_check 
        if [ $? -ne 0 ]; then
            upgrade_logger "${PLATFORM_NAME} Upgrade process: basic system checking fail"
            return 1
        fi
        upgrade_logger "${PLATFORM_NAME} Upgrade process: building partition 2 image"
        build_partition2_image "" $source "/etc/picos/p2files.lst"
        # check if success
        status=$(get_fs_status "secondary" ${path})
        if [[ "$status" != "ready" ]]; then
            # error !
            upgrade_logger "${PLATFORM_NAME} Upgrade process: fail to build partition 2 image"
            umount /mnt/sd_card
            return 2
        fi
        if [ -f /mnt/sd_card/boot/rootfs.ext2.gz.uboot ]; then
             cp /mnt/sd_card/boot/rootfs.ext2.gz.uboot ${source}/boot/
        fi
    fi
    upgrade_logger "${PLATFORM_NAME} Upgrade process: partition 2 image ready"

    # update partition 2
    upgrade_logger "${PLATFORM_NAME} Upgrade process: cleaning up partition 2 ..."
    rm -rf /mnt/sd_card/*
    sync
    upgrade_logger "${PLATFORM_NAME} Upgrade process: updating partition 2 file system ..."
    cp -a ${source}/* /mnt/sd_card
    sync
    umount /mnt/sd_card
    rm -rf ${source}
    sync
    set_fs_status "secondary" ${path} "ok"
    upgrade_logger "${PLATFORM_NAME} Upgrade process: partition 2 file system updated"
    return 1
}

#set_fs_status "secondary" "/etc/picos" "ok"
update_partition2 "${BACKUP_STORAGE_DEV}" "/cftmp/p2" "/etc/picos" 
