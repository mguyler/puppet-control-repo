#!/bin/bash


#create dev node
create_dev_node()
{
    #make node in dev dir for SDK
    if [ ! -c /dev/linux-kernel-bde ];then
        mknod /dev/linux-kernel-bde c 127 0
    fi

    if [ ! -c /dev/linux-user-bde ];then
        mknod /dev/linux-user-bde c 126 0 
    fi

    if [ ! -c /dev/net/tun ];then
        mknod /dev/net/tun c 10 200
    fi

    #dir and dev files for rtc
    if [ ! -d /dev/misc ];then
       mkdir /dev/misc
    fi

    if [ ! -c /dev/misc/rtc ];then
       mknod /dev/misc/rtc c 254 0
    fi

    if [ ! -c /dev/wdtDev ];then
       mknod /dev/wdtDev c 245 1
    fi

    rm -fr /dev/rtc
    mknod /dev/rtc c 254 0
}

#insmod module
install_kernel_module()
{

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/ip_tables.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/ip_tables.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/iptable_filter.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/iptable_filter.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/ipt_REJECT.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/ipt_REJECT.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/iptable_mangle.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/iptable_mangle.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/netfilter/xt_mark.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/netfilter/xt_mark.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/netfilter/xt_dscp.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/netfilter/xt_dscp.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/netfilter/xt_mac.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/netfilter/xt_mac.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/netfilter/xt_LOG.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/netfilter/xt_LOG.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/netfilter/xt_NFLOG.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/netfilter/xt_NFLOG.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6_tables.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6_tables.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6table_filter.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6table_filter.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6t_REJECT.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6t_REJECT.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6t_frag.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6t_frag.ko
    fi

    if [ -f /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6table_mangle.ko ];then
        insmod /lib/modules/`uname -r`/kernel/net/ipv6/netfilter/ip6table_mangle.ko
    fi

    if [ -e /lib/modules/i2c-ismt.ko ];then
        insmod /lib/modules/i2c-ismt.ko
    fi

    echo "as571x_54x_syspld 0x60" > /sys/class/i2c-adapter/i2c-0/new_device
    echo "as571x_54x_syspld 0x61" > /sys/class/i2c-adapter/i2c-0/new_device
    echo "as571x_54x_syspld 0x62" > /sys/class/i2c-adapter/i2c-0/new_device
    
    echo "pca9548 0x70" > /sys/class/i2c-adapter/i2c-1/new_device
    echo "lm75 0x48" > /sys/class/i2c-adapter/i2c-7/new_device
    echo "lm75 0x49" > /sys/class/i2c-adapter/i2c-8/new_device
    echo "lm75 0x4a" > /sys/class/i2c-adapter/i2c-9/new_device

    echo "psu_eeprom 0x38" > /sys/class/i2c-adapter/i2c-3/new_device 
    echo "psu_eeprom 0x3b" > /sys/class/i2c-adapter/i2c-4/new_device    
    echo "psu_pmbus 0x3c" > /sys/class/i2c-adapter/i2c-3/new_device          
    echo "psu_pmbus 0x3f" > /sys/class/i2c-adapter/i2c-4/new_device  
    
    echo "qsfp 0x50" > /sys/class/i2c-adapter/i2c-0/new_device
    echo "sfp 0x51" > /sys/class/i2c-adapter/i2c-0/new_device
    
    echo "hwinfo 0x57" > /sys/class/i2c-adapter/i2c-1/new_device

    if [ -e /lib/modules/cpld.ko ];then
        insmod /lib/modules/cpld.ko
    fi

    if [ -e /lib/modules/accton_as5712_54x_fan.ko ];then
        insmod /lib/modules/accton_as5712_54x_fan.ko
    fi

    if [ -e /lib/modules/pmbus.ko ];then
        insmod /lib/modules/pmbus.ko
    fi

    if [ -e /lib/modules/access_control.ko ];then
        insmod /lib/modules/access_control.ko
    fi
  
    if [ -e /lib/modules/sfp.ko ];then
        insmod /lib/modules/sfp.ko
    fi
 
    if [ -e /lib/modules/qsfp.ko ];then
        insmod /lib/modules/qsfp.ko
    fi

    if [ -e /lib/modules/hwinfo.ko ];then
        insmod /lib/modules/hwinfo.ko
    fi

    if [ -e /lib/modules/lm75.ko ];then
        insmod /lib/modules/lm75.ko
    fi

    if [ -e /lib/modules/fan_controller.ko ];then
        insmod /lib/modules/fan_controller.ko
    fi

    if [ -e /lib/modules/iTCO_vendor_support.ko ];then
        insmod /lib/modules/iTCO_vendor_support.ko
    fi
 
    if [ -e /lib/modules/iTCO_wdt.ko ];then
        insmod /lib/modules/iTCO_wdt.ko
    fi

    insmod /lib/modules/linux-kernel-bde.ko
    insmod /lib/modules/linux-user-bde.ko

}

get_box_name()
{
    as5712_formal="as5712_54x"
    hp5712_formal="HP5712"
    hp6920_formal="HPE AL 6920"

    product_name=`cat /sys/class/hwinfo/product_name`
    is_hp5712=`echo "$product_name" | grep "HP" | grep "5712"`
    is_hp6920=`echo "$product_name" | grep "HP" | grep "6920"`
    if [ -n "$is_hp5712" ]; then
        echo "$hp5712_formal"	
    elif [ -n "$is_hp6920" ]; then
        echo "$hp6920_formal"	
    else
        echo "$as5712_formal"
    #else 
    #    echo `grep "DISTRIB_MACHINE" /pica/etc/lsb-release | awk -F '=' '{print $2}'`
    fi
}

update_box_name()
{
    # update box name in /etc/lsb-release 
    box_name=`get_box_name`
    sed -i "s/\(DISTRIB_DESCRIPTION=Pica8 PicOS for\) .* \(Release .*\)/\1 ${box_name} \2/g" /etc/lsb-release
    sed -i "s/\(DISTRIB_DESCRIPTION=Pica8 PicOS for\) .* \(Release .*\)/\1 ${box_name} \2/g" /pica/etc/lsb-release
    sed -i "s/\(DISTRIB_DESCRIPTION=Pica8 PicOS for\) .* \(Release .*\)/\1 ${box_name} \2/g" /ovs/etc/lsb-release
}

#some hardware-related work
do_other_hw_dep_work()
{
    #set the system from rtc
    /etc/init.d/hwclock.sh start
    if [ -x /pica/bin/system/hw_dep_init ]; then
       ldconfig
       /pica/bin/system/hw_dep_init
    fi

    #set box name by eeprom
    update_box_name
}
#Bug4112 when connecting switch port of 100Mb speed eth0 cannot work well
sudo ethtool -s eth0 duplex full

#Bug 5482, 5740, 5782
#Do not monitor or correct perf's sampling rate no matter how CPU time it takes.
echo 0 > /proc/sys/kernel/perf_cpu_time_max_percent
