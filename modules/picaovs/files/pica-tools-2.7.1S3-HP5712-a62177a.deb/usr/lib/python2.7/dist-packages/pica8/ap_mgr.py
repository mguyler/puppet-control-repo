from ap_dispatcher import ap_dispatcher

def main():
    ap = ap_dispatcher('/usr/lib/python2.7/dist-packages/pica8/')
    ap.dispatch()

if __name__ == '__main__':
    main()
