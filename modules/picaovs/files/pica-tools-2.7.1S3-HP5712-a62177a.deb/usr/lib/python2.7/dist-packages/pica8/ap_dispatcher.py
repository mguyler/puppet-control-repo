import os, sys, time, copy, json
from ap_task import ap_task

ovs = {'app':'OVS', 'procs':[{'task':'ovsdb-server','check':'ovsdb-ser'},{'task':'ovs-vswitchd','check':'"worker process"'}]}
xorp = {'app':'XorPlus', 'procs':[{'task':'xorp_rtrmgr','check':'xorp_rtr'},{'task':'/pica/bin/pica_sh','check':'/pica_sh'}]}

TARGET_FILE = 'provision-target.lst'

class ap_dispatcher:
    def __init__(self, path = ''): 
        self.path = path
        self.target_file = os.path.join(path, TARGET_FILE) 
        self.completed_targets = []
        self.provision_targets = []

        # task executor
        ap = ap_task(echo = False)
        ap.start() 
        self.switch = ap.switch()
        self.ap = ap
        
    # main loop, build provision target lists, and process
    # provision targets - upgrade before Pica application start
    def dispatch(self):
        # read in target lists
        self.read_targets()

        #check the status of partition two
        if not self.ap.check_status_partition_two():
            self.ap.log("info", 'Partition 2 is not ready')
            self.ap.on_exit_normal_info('Partition 2 is not ready')
            return

        # check if exists any outstanding task
        if self.provision_targets == [] and self.application_targets == []:
            # no existing tasks, get script from DHCP server
            #script_file = self.ap.get_script_file()
            self.ap.dhcpclient()
            script_file = self.ap.get_script_file()
            script = self.read_script(script_file)
            
            # build active target list and app target list
            stamp = self.timestamp()
            script_name = script_file + "." + stamp
            provision_targets = self.target_list_from_script(script, "provision targets", stamp, script_name)
            application_targets = self.target_list_from_script(script, "configuration targets", stamp, script_name)
            self.provision_targets = self.get_provision_targets(provision_targets, self.completed_targets)
            self.application_targets = self.get_provision_targets(application_targets, self.completed_targets)
            self.save_targets()
            
            if self.provision_targets == [] and self.application_targets == []:
                print 'Auto Provisioning: no active tasks. Start Pica8 application .....'
                self.ap.log('info', 'no active tasks. Start Pica8 application .....')
                return False    # continue to start Xorp/OVS
            else:
                # save script for later reference
                print 'Auto Provisioning: saving script %s ' % script_name
                self.ap.log('info', 'saving script %s ' % script_name)
                self.save_script(script_name, script)
                self.display_targets()
        
        # provision targets - upgrade before Pica application start
        self.process_targets(self.provision_targets, targets_type='provision')
        
    # application targets - configuration tasks after Pica application starts
    def dispatch_app(self):
        # read in target lists
        self.read_targets()
        # process app targets (after Pica application starts)
        self.process_targets(self.application_targets, targets_type='configuration')
        
    # loop: processing provision targets
    def process_targets(self, target_list, targets_type):
        # continue process next target
        while len(target_list) > 0:
            target = target_list[0]
            self.script = self.read_script(target["script"])
            task_index = target["next-task"]
            tasks = self.script["provision tasks"]
            
            # process tasks in current target
            for i in range(task_index, len(target["tasks"])):
                task = tasks[target["tasks"][i]]
                # special case: reboot
                #print ' ==== target: %s  task: %s ====' % (target["target"], target["tasks"][i])
                if task["type"] == "reboot":
                    if target["state"] == "reboot":
                        # we are here from reboot, get tftp server again
                        #self.ap.get_script_file()
                        self.ap.get_tftp_server_info()
                        # move to next task
                        #print ' ==== after reboot, next task %d ====' % (target["next-task"])
                        if i < len(target["tasks"]) - 1:
                            continue
                        else:
                            # this is the last task in list
                            break
                    # ready to reboot: do not change next_task, just change the state and save target lists
                    target["state"] = "reboot"
                    target["next-task"] = i
                    #print ' ==== before reboot, next task %d ====' % (target["next-task"])
                    self.save_targets()

                #print ' ==== execute task %s : %s ====' % (target["target"], target["tasks"][i])
                task_res = self.ap.do_task(task)
                if task_res == False:
                    del(target_list[0])
                    if targets_type =='provision':
                        self.provision_targets = []
                    elif targets_type =='configuration':
                        self.application_targets = []
                    self.save_targets()
                    return False
                    
                # simulate reboot, will never be here if execute reboot
                if task["type"] == "reboot":
                    return True
                
            # move to next target, update target lists
            target['state'] = 'done'
            self.completed_targets.append(target)
            del(target_list[0])
            self.save_targets()

        # Finished doing target upgrade
        self.save_targets()
        return True
        
    def display_targets(self):
        #self.read_targets()
        print ' ----- complete list ------- '
        self.printdict(self.completed_targets)
        print ' ----- active provision list ------- '
        self.printdict(self.provision_targets)
        print ' ----- active configuration list ------- '
        self.printdict(self.application_targets)

    # list of target: keep provision history
    def target(self, name, tasks, vsn_no, prev_vsn_no, state, next_task, timestamp, script):
        return {'target': name,               # provision target
                'tasks': tasks,               # task list
                'version': vsn_no,            # seq no
                'prev-version': prev_vsn_no,  # seq no before upgrade
                'state': state,               # status
                'next-task': next_task,       # next active task
                'timestamp': timestamp,       # created/complete time
                'script': script}             # defined in which script file            
 
    # target list is what's in target file
    def target_list_from_script(self, script, type, sdate, script_file):
        target_list = []
        provision = script[type]
        for i in provision["item"]:
            # make sure this is for me
            if 'host' in provision[i]:
                if 'all' not in provision[i]['host'] and self.switch['mac'] not in provision[i]['host'] and self.switch['model'] not in provision[i]['host']:
                    continue
            # get version number (direct or indirect)
            prev_vsn_no = '' 
            if provision[i]["version-number"] in ['version', 'revision']:
                vsn_no = provision[i][provision[i]["version-number"]]
                # use current version number as prev-seq-no
                if i in ['picos', 'pica']:
                    prev_vsn_no = self.switch[provision[i]["version-number"]]
            else:
                vsn_no = provision[i]["version-number"]
            # create provisioning target, append type to target name in case similar names appear in both lists
            t = self.target(i + '.' + type[:4], 
                            provision[i]["task"],
                            vsn_no,
                            prev_vsn_no,
                            "active",
                            0,
                            sdate,
                            script_file)
            # add to list
            target_list.append(t)
        return target_list
 
    # compare targets with completed target list, generate active target list
    def get_provision_targets(self, new_list, completed_list):
        active_list = []
        for i in new_list:
            # skip those already have prev version number
            if i['prev-version'] != '': 
                continue                
            for j in completed_list[::-1]:
                # get prev version number
                if i["target"] == j["target"]:
                    i['prev-version'] = j['version']
                    break

        # create active target list
        for i in new_list:
            if i['prev-version'] != i['version']:
                active_list.append(i)

        return active_list
 
    # read in target lists
    def read_targets(self):
        data = self.read(self.target_file)
        self.completed_targets = data["completed-targets"]
        self.provision_targets = data["provision-targets"]
        self.application_targets = data["configuration-targets"]

    def remove_unused_script(self, completed_list, new_list):
        def script_exists(task):
            for unique_task in new_list:
                if unique_task["script"] == task["script"]:
                    return True
            return False

        for task in completed_list:
            if not script_exists(task):
                if os.path.isfile(task["script"]):
                    os.remove(task["script"])


    #remove the old history of complete list
    def unique_complete_target(self,completed_list):
        new_list = []
        def exists(task):
            for unique_task in new_list:
                if unique_task["target"] == task["target"]:
                    return True
            return False

        for task in completed_list[::-1]:
            if not exists(task):
                new_list.append(task)

        #self.remove_unused_script(completed_list, new_list)

        return new_list[::-1]


        
    # save target list
    def save_targets(self):
        old_completed_targets = self.completed_targets
        self.completed_targets = self.unique_complete_target(self.completed_targets)
        self.remove_unused_script(old_completed_targets, self.completed_targets)
        data = {"completed-targets" : self.completed_targets, "provision-targets" : self.provision_targets, "configuration-targets" : self.application_targets}
        self.write(self.target_file, data)
        
    # read in script file
    def read_script(self, script_file):
        return self.read(script_file)
        
    # save script file
    def save_script(self, script_file, script):
        self.write(script_file, script)
           
    # replace constants in script
    def convert_script(self, data):
        d = json.loads(data)
        if 'const' in d:
            self.switch["ip"] = self.ap.get_ipaddr()
            const = dict(d["const"].items() + self.switch.items())
            if "format" in const:
                tags = const["format"].split("name")
            else:
                tags = ["${", "}"]
            for k in const.keys():
                data = data.replace(tags[0] + k + tags[1], const[k])
            d = json.loads(data)
        return d

    # read file in JSON format, return a dictionary
    def read(self, file):
        dict = {}
        fd = None
        try:
            fd = open(file, "r")
            data = fd.read()
            #dict = json.loads(data)
            dict = self.convert_script(data)
        except IOError:
            self.ap.on_error('Error reading file : %s\n' % file)
        finally:
            if fd != None:
                fd.close()

        return dict
        
    # write file in JSON format
    def write(self, file, data, sort=False):
        try:
            jsondata = json.dumps(data, indent=4, skipkeys=True, sort_keys=sort)
            fd = open(file, 'w')
            fd.write(jsondata)
        except IOError:
            self.ap.on_error('  *** Error writing file : %s\n' % file)
        finally:
            fd.close()
    
    # timestamp in hex string
    def timestamp(self):
        # timestamp in seconds
        t = int(time.time())
        # return hex string of timestamp
        return str(hex(t))[2:]
        
    # pretty print
    def printdict(self, dct, sort=False):
        print json.dumps(dct, sort_keys=sort, indent=4)


def main():
    apm = ap_dispatcher()
    apm.dispatch()
    #script = apm.read('simple.provision.script')
    #apm.printdict(script)

def test_process():
    apm = ap_dispatcher()
    apm.read_targets()
    print ' ----- old list ------- '
    apm.printdict(apm.completed_targets)
    print ' ----- new list ------- '
    apm.printdict(apm.provision_targets)
    apm.dispatch()
    print ' ----- old list ------- '
    apm.printdict(apm.completed_targets)
    print ' ----- new list ------- '
    apm.printdict(apm.provision_targets)
    
  
if __name__ == '__main__':
    main()

