#!/bin/bash

. /etc/functions


# TODO: check if had been mounted, don't use remount option if not mounted
#mount -o remount,rw,noatime /

#mount ramdisk
#mke2fs /dev/ram0 > /dev/null 2>&1
#mount /dev/ram0 /tmp
chown 0:1 /tmp
chmod 777 /tmp
# /tmp/log is used for syslog
mkdir /tmp/log
chown 0:1 /tmp/log
chmod 775 /tmp/log
#touch the default syslog output file
touch /tmp/log/messages
chown 0:1 /tmp/log/messages
chmod 775 /tmp/log/messages

if [ ! -f /var/log/messages ]; then
    touch /var/log/messages
fi
chown 0:1 /var/log/messages
chmod 775 /var/log/messages

touch /tmp/log/lastlog
chown root:utmp /tmp/log/lastlog
chmod 664 /tmp/log/lastlog
if [ -f /var/log/lastlog ];then
    rm -fr /var/log/lastlog
fi
ln -s /tmp/log/lastlog /var/log/lastlog

touch /tmp/log/wtmp
if [ -f /var/log/wtmp ];then
    rm -fr /var/log/wtmp
fi
ln -s /tmp/log/wtmp /var/log/wtmp

#/tmp/system is used for system file
mkdir /tmp/system
chown 0:1 /tmp/system
chmod 777 /tmp/system
#/tmp/run is used for system run status
mkdir /tmp/run
chown 0:1 /tmp/run
chmod 775 /tmp/run

mkdir /tmp/run/crontab
chown 0:1 /tmp/run/crontab

if [ -e /var/spool/cron ];then
    rm -fr /var/spool/cron
fi

ln -s /tmp/run/crontab /var/spool/cron

mkdir /tmp/run/crontab/crontabs
chgrp crontab /tmp/run/crontab/crontabs

#/home is used for users 
chmod 775 /home
if [ ! -d /home/admin ];then
    mkdir /home/admin
fi
if [ ! -d /home/operator ];then
    mkdir /home/operator
fi

chown root:1 /root
chown admin:1 /home/admin
chown operator:1 /home/operator

# to provide standard i/o files as links
rm -f /dev/stdin
rm -f /dev/stdout
rm -f /dev/stderr
ln -s /proc/self/fd/0 /dev/stdin
ln -s /proc/self/fd/1 /dev/stdout
ln -s /proc/self/fd/2 /dev/stderr


# change permission; TODO:make better permission plan later
chmod 700 /etc/radvd.conf
# clear radvd.conf
sed -i "/# begin for interface/,/# end for interface/d" /etc/radvd.conf

# Only for prompt
hostname XorPlus

# For sshd
chmod 600 /var/empty /etc/ssh/ssh_host_dsa_key /etc/ssh/ssh_host_rsa_key
chown root:root /var/empty /etc/ssh/ssh_host_dsa_key /etc/ssh/ssh_host_rsa_key

ldconfig

#disable tac and enable local auth for root to auto login on console.
#/pica/bin/shell/tacacs_disable.sh true
sed -i 's/\(^#*\)\(.*\)pam_unix\(.*\)/\2pam_unix\3/g' /etc/pam.d/common-auth


