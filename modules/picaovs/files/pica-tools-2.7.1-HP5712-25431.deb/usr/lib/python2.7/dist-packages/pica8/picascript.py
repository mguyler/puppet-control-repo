#!/usr/bin/env python

#  Pica8 script sample application
#
#          PicaExpect
#
#  This tool provides following methods:
#
#   - expect(command, prompts, timeout)
#       executes a command, returns matched index of prompts in output,
#       or -1 if no match or timeout   
#
#   - expectplus(command, prompts, timeout)
#       executes cmd, returns tuple (index, output, matched string)   
#
#   - extract(command, prompts, pattern, timeout)
#       executes cmd, returns tuple (index, output, matched patterns)   
#
#   - run(cmd, run_only)
#       executes cmd that can be a single command or a list of commands, 
#       returns output or empty string if run_only  
#

import logging
import logging.handlers

from picacommand import *

#  Pica8 script tool: PicaExpect
class PicaExpect:
    
    XORP_ACCOUNT = "admin"
    OVS_ACCOUNT = "root"
    PASSWORD = "pica8"
    DEFAULT_TIMEOUT = 10
    DEFAULT_PROMPTS = ['root@XorPlus>', '\r\n.+@.+[#>:]', '\r.*@.*[#>:]', '\n.+@.+[#>:]', 'XorPlus[#>]']

    def __init__(self, mode = Mode.shell, host='127.0.0.1', user = OVS_ACCOUNT,\
                 passwd = PASSWORD, sleep = 0.5, timeout = DEFAULT_TIMEOUT, \
                 prompt = DEFAULT_PROMPTS, cmd_prompt = '# ', echo = True):
        self._session = None
        if mode == Mode.telnet:
            self.ci = telnet(mode, user, passwd, host, sleep, prompt, \
                             timeout, echo = echo)
        elif mode == Mode.shell:
            self.ci = shell(mode, 0, timeout = timeout, prompt = prompt, \
                            cmd_prompt = cmd_prompt, echo = echo)
        elif mode == Mode.ssh:
            self.ci = ssh(mode, user, passwd, host, echo = echo)
        else:
            print "Error: invalid mode: %s" % mode
            exit(1)
        self.syslogger = self.syslog_handler_init()


    def syslog_handler_init(self, address = '/dev/log', facility=logging.handlers.SysLogHandler.LOG_LOCAL0, level=logging.DEBUG):
        my_logger = logging.getLogger('Auto-Provision')
        my_logger.setLevel(level)
        #fmt = ' [%(name)s] [%(processName)s] %(message)s'
        fmt = ' [%(name)s] %(message)s'
        f = logging.Formatter(fmt)
        handler = logging.handlers.SysLogHandler(address,facility)
        # plug this formatter into your handler(s)
        handler.setFormatter(f)
        my_logger.addHandler(handler)
        return my_logger

    def log(self, level="debug", msg=''):
        if level == "debug":
            self.syslogger.debug(msg)
        elif level == "error":
            self.syslogger.error(msg)
        elif level == "info":
            self.syslogger.info(msg)
        elif level == "warning":
            self.syslogger.warning(msg)
        elif level == "critical":
            self.syslogger.critical(msg)
        return True
            

    # must be called if telnet or ssh        
    def start(self):
        self.ci.start()

    # must be called if telnet or ssh        
    def stop(self):
        self.ci.stop()

    # which protocol we are using        
    def mode(self):
        mode = self.ci.mode
        if (mode == Mode.shell):
            mode = 'shell'
        elif (mode == Mode.telnet):
            mode = 'telnet'
        elif (mode == Mode.ssh):
            mode = 'ssh'
        else:
            self.on_error("Error: invalid mode: " + mode)
        return mode

    # tcl expect: returns index or -1 if fails
    def expect(self, cmd, expected = None, timeout = None):
        r = self.ci.expect(cmd, expected, timeout)
        #return r.index
        return r[0]

    # returns tuple: (index, output, output) or (-1, output, error msg)
    def expectplus(self, cmd, expected = None, timeout = None):
        r = self.ci.expect(cmd, expected, timeout)
        return r

    # returns tuple (index, output, matched data) or (-1, output, error msg)
    def extract(self, cmd, pattern, expected = None, timeout = None, echo = True):
        r = self.ci.extract(cmd, expected = expected, pattern = pattern, match_type = Match.FindAll, timeout = timeout, echo = echo)
        return r
        
    # run a single or a list of commands, returns output 
    def run(self, cmd, sleep = None, run_only = False):
        return self.ci.run(cmd, run_only = run_only, sleep = sleep)

    # start an application session in shell, and interactive with it
    def start_app_session(self, cmd, prompt, run_only = False, app_cmd_prompt = '> ', app_echo = "True"): 
        if self.mode() != 'shell':
            return 'Error: not in shell mode'
        return self.ci.app_begin(cmd, prompt, run_only, app_cmd_prompt, app_echo)
   
    # stop an application session, and return to shell
    def stop_app_session(self, exit_cmd): 
        return self.ci.app_end(exit_cmd, [''])

    # create a telent session
    def app_session(self, prompt = DEFAULT_PROMPTS):
        return PicaExpect(mode = Mode.telnet, prompt = prompt)

    # start session with session prompt
    def start_session(self, session, cmd):
    
        # to do: enable telnet

        session.start()
        r = session.expect(cmd)
        return r

    # stop session with main session prompt
    def stop_session(self, session, cmd):
        r = session.expect(cmd, self.prompt)
        session.stop()
        
        # to do: disable telnet
        
        return r

    def printline(self, s):
        #sl = s.replace(self.newline, '\n')
        sl = s
        sys.stdout.write(sl)

    def sleep(self, t):
        time.sleep(t)

    def on_error(self, msg):
        sys.stdout.write("\nError: " + msg + "\n")
        self.stop()
        sys.stdout.write(" --- exit --- \n")
        self.log('error', msg)
        exit(1)

    def on_error_without_exit(self, msg):
        sys.stdout.write("\nError: " + msg + "\n")
        self.stop()
        self.log('error', msg)
        sys.stdout.write(" --- exit --- \n")

    def on_exit_normal_info(self, msg):
        sys.stdout.write("\n " + msg + "\n")
        self.stop()
        sys.stdout.write("Pica8 Auto Provisioning Tool - Done\n")
        self.log('info', "Pica8 Auto Provisioning Tool - Done")
        exit(0)

    '''
    #def __init__(self, mode = Mode.xorp, host='localhost', user = XORP_ACCOUNT, passwd = PASSWORD, \
    def __init__(self, mode = Mode.ovs, host='localhost', user = OVS_ACCOUNT, passwd = PASSWORD, \
                 sleep = 0.5, timeout = DEFAULT_TIMEOUT, prompt = DEFAULT_PROMPTS):
        if mode in [Mode.telnet, Mode.xorp, Mode.config, Mode.pica_sh, Mode.uboot]:
            self.ci = telnet(mode, user, passwd, host, sleep, prompt, timeout)
        elif host == 'localhost':
            self.ci = shell(mode, 0, timeout = timeout, prompt = prompt)
        else:
            self.ci = ssh(mode, user, passwd, host)
    def __init__(self, mode = Mode.ovs, host='localhost', user = OVS_ACCOUNT, passwd = PASSWORD, \
                 sleep = 0.5, timeout = DEFAULT_TIMEOUT, prompt = DEFAULT_PROMPTS, cmd_prompt = '# ', echo = True):
        if mode in [Mode.telnet, Mode.xorp, Mode.config, Mode.pica_sh, Mode.uboot]:
            self.ci = telnet(mode, user, passwd, host, sleep, prompt, timeout)
        elif host == 'localhost':
            self.ci = shell(mode, 0, timeout = timeout, prompt = prompt)
        else:
            self.ci = ssh(mode, user, passwd, host)
    '''
    '''
    # stop an application session, and return to shell
    def stop_app_session(self, cmd): 
        r = self._session.expect(cmd, self.prompt)
        return r

    def app_session(self, prompt, run_only = False, app_cmd_prompt = '> '): 
        session = PicaExpect(mode = Mode.telnet)
        session._prompt = prompt
        session._run_only = run_only
        session._app_cmd_prompt = app_cmd_prompt
        session._session = 'stopped'
        return session

    def start_session(self, cmd):
        if self._session is None or self._session != 'stopped' :    
            self.on_error("Error: Not a session instance or session not ready" )
        r = self.ci.app_begin(cmd, self._prompt, self._run_only, self._app_cmd_prompt)
        self._session = 'started'
        return r

    # stop an application session, and return to shell
    def stop_session(self, exit_cmd): 
        if self._session is None or self._session != 'started' :    
            self.on_error("Error: Not a session instance or session not running" )
        r = self.ci.app_end(exit_cmd, [''])
        self._session = 'stopped'
        return r    
    '''

def main():
    test_expect()
    test_exception()

  
def test_expect():

    #host = '172.16.0.123'
    host = '127.0.0.1'

    imgfile = 'pica8/picos-2.1.0-3295-r11529.tar.gz'
    tftpserver = '172.16.0.189'

    shell_cmds = ['cd /', 'pwd', 'df', 'ps | grep etc', 'ifconfig | grep Bcast']
    std_promts = ['root@XorPlus>', '\w+@\w+[#>:$]', 'XorPlus>', 'XorPlus#', '#', '> ']
    
    print "\n\n  ======= telnet TEST =======\n"

    e = PicaExpect(Mode.telnet, host, echo = False) #, PicaExpect.OVS_ACCOUNT, PicaExpect.PASSWORD, 1)
    e.start()
    
    # test run
    print e.run(shell_cmds)
    print "------------\n"
    
    # test expect 
    print e.expect('pwd')
    print "------------\n"
    print e.expectplus('pwd')
    print "------------\n"
    
    # test extract
    pattern = '(\/\w+\/\w+)\s.*\s(\d+%)\s(\/.*)\r\n'
    match = e.extract("df", pattern, std_promts)
    print match.response
    print "------------\n"
    print match.data   
    print "------------\n"
    
    # XorPlus
    rsp = e.expectplus('/pica/bin/pica_sh', ["XorPlus> ", "Password: ", "password:"], 10)
    if (rsp[0] == 0):
        print(rsp[2])

        print("\n--- Enter XorPlus ---\n")
        xorp_promts = ["Commit", "mac_phy", "XorPlus>", "XorPlus#", "#", "> "]
        xorp_cmds = ['configure', 'help', \
                     'set protocols lldp hold-time-multiplier 5', \
                     'commit', \
                     'run show lldp detail', \
                     'set protocols lldp hold-time-multiplier 2', \
                     'commit', \
                     'run show lldp detail', \
                     'quit']
        xorp_cmds_2 = ['configure', \
                     'show interface gigabit-ethernet te-1/1/1', \
                     'set interface gigabit-ethernet te-1/1/1 speed 1000', \
                     'commit', \
                     'show interface gigabit-ethernet te-1/1/1', \
                     'set interface gigabit-ethernet te-1/1/1 speed 10000', \
                     'commit', \
                     'show interface gigabit-ethernet te-1/1/1', \
                     'quit']
        print e.expectplus('show system os', xorp_promts).response
        print "------------\n"
        print e.run(xorp_cmds, xorp_promts)
        print "------------\n"
        print e.run(xorp_cmds_2, xorp_promts)
        print "------------\n"
        print e.expectplus('show system date', xorp_promts).response

    e.stop()

    '''

    print "\n\n  ======= ssh TEST =======\n"

    # ssh   
    e = PicaExpect(Mode.ssh, host, PicaExpect.OVS_ACCOUNT, PicaExpect.PASSWORD, 0.1)
    e.start()

    # test run
    print e.run(shell_cmds)
    print "------------\n"

    # test expect
    print e.expect('pwd')
    print "------------\n"
    print e.expectplus('pwd')
    print "------------\n"

    # test extract
    pattern = '(\/\w+\/\w+)\s.*\s(\d+%)\s(\/.*)\r\n'
    match = e.extract("df", pattern, std_promts)
    print match.response
    print "------------\n"
    print match.data
    print "------------\n"
    '''

    print "\n\n  ======= shell TEST =======\n"

    # Shell
    e = PicaExpect(Mode.shell, timeout = 2, echo = True)
    print("\n--- Shell ---\n")

    # test run
    #print e.run(shell_cmds)
    e.run(shell_cmds)
    print "------------\n"

    '''
    print("\n--- TFTP Test ---\n")
    print e.run('date')
    #cmd = ['atftp -g -r mk2ps3290.py -l mk2ps3290.py 172.16.0.189']
    #cmd = ['atftp --option "blksize 4096" -g -r pica8/picos-2.1.0-3295-r11529.tar.gz -l picos.tar.gz 172.16.0.189' ,'sync']
    cmd = ['atftp --option "blksize 4096" -g -r ' + imgfile + ' -l picos.tar.gz ' + tftpserver, 'sync']
    print e.run(cmd)
    print "------------\n"
    print e.run('ls -l')
    print e.run('date')
    print "------------\n"
    cmd = ['tar -xzvf picos.tar.gz' ,'sync']
    print e.run(cmd)
    print "------------\n"
    print e.run('date')
    print e.start_app_session('tftp', None, run_only = True)
    print e.run('connect 172.16.0.189', sleep = .1, run_only = True)
    print e.run('status', sleep = .1, run_only = True)
    print e.run('?', sleep = .1, run_only = True)
    print e.stop_app_session('q')
    print "------------\n"
    time.sleep(5)
    print e.run('date')
    print e.run('ls -l')
    print "------------\n"
    time.sleep(5)
    print e.run('date')
    '''

    print("\n--- XorPlus Test ---\n")
    #print e.start_app_session('/pica/bin/pica_sh', ['XorPlus>', 'XorPlus#'], run_only = False, app_cmd_prompt = ''),
    e.start_app_session('/pica/bin/pica_sh', ['XorPlus>', 'XorPlus#'], app_echo = False),
    #print e.run(['show host os', 'show version', 'configure', 'quit', 'show host date', 'show system fan', 'show system uptime'])
    e.run('show system os'), 
    e.run('show version'), 
    e.run('configure'), 
    e.run('quit'), 
    e.run('show system date'), 
    e.run('show system fan'), 
    e.run('show system uptime'), 
    # match all
    r = e.extract('show system uptime', pattern='.*up\s+(\d+)\s+days,\s+(\d+):(\d+),') 
    print 'match=%s' % str(r[2])
    print 'system up time is %s days, %s hours, and %s minutes' % r[2][0]
    e.stop_app_session('quit')

    '''
    # works on CentOS
    e.ci.app_begin('tftp', 'tftp>')
    e.run('abc')
    e.run('help')
    e.run('status')
    e.ci.app_end('quit' ,'')
    '''
    
    # test expect
    print e.expect('pwd')
    print "------------\n"
    print e.expectplus('pwd')
    print "------------\n"

    # test extract
    #pattern = '(\/\w+\/\w+)\s.*\s(\d+%)\s(\/.*)\r\n'
    pattern = '(\/\w+\/\w+)'
    match = e.extract("df", pattern)
    print match.response
    print "------------\n"
    print match.data


def test_exception():

    e = PicaExpect()
    e.start()

    print '\n   -------- command with exceptions --------\n'
    action = [
        "cd ..",
        "pwd",
        {"cmd":"ls -l",
         "exception-with":["provision-target.lst"],
         "exception-without-all":["config.bcm", "rc.soc", "selinux", "ap_cfg.py"
],
         "exception-without-any":["dispatcher", "ap_mgr", "script"],
         "on-exception":{"do":["df", "date"],
                         "msg":"ls -l : error"}
        },
        "version",
        {"cmd":"ls -l /var/spool/cron",
         "exception-without-any":["crontab", "\w+\s+\d+\s+[\d:]+"],
         "on-exception":{"msg":"tar error: rootfs.tar.gz extract incomplete"}
        },
        "uname"
    ]
    print "\n   ------- cmd list -----\n"
    for i in action:
        print e.expect(i)
    print "\n   ------- run -----\n"
    e.run(action)

    e.stop()
    print '\n   -------- end of test --------\n'

if __name__ == '__main__':
    main()


