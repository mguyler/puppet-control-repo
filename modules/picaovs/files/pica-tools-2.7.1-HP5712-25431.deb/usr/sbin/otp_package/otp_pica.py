#!/usr/bin/env python2.7

# Copyright (c) 2009-2014 Pica8, Inc.
# http://pica8.org


# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License, Version
# 2.1, June 1999 as published by the Free Software Foundation.
# Redistribution and/or modification of this program under the terms of
# any other version of the GNU Lesser General Public License is not
# permitted.

# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. For more details,
# see the GNU Lesser General Public License, Version 2.1, a copy of
# which can be found in the LICENSE file.

import os
import subprocess
from otp_util import cidr_to_ipmaskstr
from otp_util import call_with_command_line
from otp_util import call_ignore_error_msg
"""
Some functions related with pica8
"""

class PicaConfig(object):
    mode_xorpplus = "xorpplus"
    mode_ovs = "ovs"
    pica_config_file = "/etc/picos/picos_start.conf"
    pica_os_service_path = "/etc/init.d/picos"
    pica_provision_script_download_path = "/cftmp/provision.py"
    pica_xorpplus_cli = "/pica/bin/pica_sh"
    pica_upgrade_bin = "/usr/sbin/upgrade"

    @classmethod
    def __pica_service(cls, cmd):
        cmd = "%s %s" % (cls.pica_os_service_path, cmd)
        ok = subprocess.call(cmd, shell=True)
        if ok != 0:
            return False
        return True

    @classmethod
    def pica_otp_set_disable_configfile(cls, disable):
        """Set otp disable or not
        """
        assert(type(disable) == bool)
        if disable == True:
            cmd = "sed -i 's/\(.*\)otp_disable=\(.*\)/otp_disable=true/g' %s" \
              % cls.pica_config_file
        elif disable == False:
            cmd = "sed -i 's/\(.*\)otp_disable=\(.*\)/otp_disable=false/g' %s"\
              % cls.pica_config_file
        else:
            cmd = None

        if cmd != None:
            ok = subprocess.call(cmd, shell=True)
            if ok != 0:
                return False
        return True

    @classmethod
    def pica_otp_get_status_configfile(cls):
        cmd = "grep otp_disable %s" % cls.pica_config_file
        res = subprocess.check_output(cmd, shell=True)
        v = res.split('=')
        #return true if a there is a error in config file
        if len(v) != 2:
            return True
        if v[1].strip() == "false":
            return False
        return True

    @classmethod
    def pica_ztp_get_status_running(cls):
        cmd = "ps -ef | grep ztp | grep -v grep | wc -l"
        line_count = subprocess.check_output(cmd, shell=True)
        if int(line_count) == 0:
            return False
        return True

    @classmethod
    def pica_ztp_terminate(cls):
        cmd = "ps -ef | grep ztp | grep -v grep | awk '{ print $2 }'"
        pid = subprocess.check_output(cmd, shell=True)
        cmd = "kill -9 %s" % pid
        ok = subprocess.call(cmd, shell=True)
        if ok != 0:
            return False
        return True

    @classmethod
    def pica_mode_get_running(cls):
        """Get picos running mode

        Returns:
          xorpplus: running on xorpplus mode
          ovs: running on ovs mode
          None: both of xorpplus and ovs are not running
        """
        cmd = "/etc/init.d/picos status|grep xorp|grep failed|wc -l"
        failed_line_count = subprocess.check_output(cmd, shell=True)
        if int(failed_line_count) == 0:
            return cls.mode_xorpplus

        cmd = "/etc/init.d/picos status|grep  ovs|grep failed|wc -l"
        failed_line_count = subprocess.check_output(cmd, shell=True)
        if int(failed_line_count) == 0:
            return cls.mode_ovs
        return None

    @classmethod
    def pica_mode_get_configfile(cls):
        cmd = "grep picos_start %s|awk -F'=' '{print $2}'" % \
          cls.pica_config_file
        return subprocess.check_output(cmd, shell=True)

    @classmethod
    def __pica_mode_xorpplus_set_configfile(cls):
        cmd = "sed -i 's/\(.*\)picos_start=\(.*\)/picos_start=xorpplus/g' %s"\
          %cls.pica_config_file
        ok = subprocess.call(cmd, shell=True)
        if ok != 0:
            return False
        return True

    @classmethod
    def __pica_mode_ovs_set_configfile(cls,cidr_ip, gw):
        cmd = "sed -i 's/\(.*\)picos_start=\(.*\)/picos_start=ovs/g' %s"\
          %cls.pica_config_file
        subprocess.call(cmd, shell=True)
        if cidr_ip != None:
            (ip_addr, mask) = cidr_to_ipmaskstr(cidr_ip)
            cmd = ("sed -i 's/\(.*\)ovs_switch_ip_address=\(.*\)/"
                   "ovs_switch_ip_address=%s/g' %s") % \
                   (ip_addr,cls.pica_config_file)
            subprocess.call(cmd, shell=True)
            cmd = ("sed -i 's/\(.*\)ovs_switch_ip_netmask=\(.*\)/"
                   "ovs_switch_ip_netmask=%s/g' %s")%(mask,cls.pica_config_file)
            subprocess.call(cmd, shell=True)
        if gw != None:
            cmd = ("sed -i 's/\(.*\)ovs_switch_gateway_ip=\(.*\)/"
                   "ovs_switch_gateway_ip=%s/g' %s")%(gw,cls.pica_config_file)
            subprocess.call(cmd, shell=True)

    @classmethod
    def pica_mode_set(cls, mode, ip=None, gw=None):
        """Switch running mode and change the config file
        If current running mode is same as mode, just modify the configfile
        else, restart picos service and modify the configfile
        Args:
          mode: xorpplus, ovs
          ip: for ovs, 1.1.1.1/24 format(cidr)
          gw: for ovs, 1.1.1.2 format
        """
        cur_running_mode = cls.pica_mode_get_running()

        if mode == cls.mode_xorpplus:
            ret = cls.__pica_mode_xorpplus_set_configfile()
            if cur_running_mode == mode:
                return
            cls.__pica_service("restart")
        elif mode == cls.mode_ovs:
            cls.__pica_mode_ovs_set_configfile(ip, gw)
            if cur_running_mode == mode:
                return
            cls.__pica_service("restart")

    @classmethod
    def pica_setup_ip4(cls, mode, interface, ip):
        cmd = "ifconfig %s %s" % (interface, ip)
        ok = subprocess.call(cmd, shell=True)
        if ok != 0:
            return False
        if mode == cls.mode_ovs:
            cls.__pica_mode_ovs_set_configfile(ip, None)
            cls.__pica_change_ovsdb_server_ptcp_remote(ip)
        elif mode == cls.mode_xorpplus:
            # TODO(gene.ge): how to save the eth0's ip in xorpplus mode
            cmd = "%s sync" % cls.pica_xorpplus_cli
            ok = subprocess.call(cmd, shell=True)
            if ok != 0:
                return False
        return True

    @classmethod
    def pica_setup_default_gw_ip4(cls, mode, gw):
        cmd = "ip -4 route del default"
        ok = subprocess.call(cmd,
                             shell=True,
                             stdout=open('/dev/null', 'w'),
                             stderr=subprocess.STDOUT)
        cmd = "ip -4 route add default via %s" % gw
        ok = subprocess.call(cmd, shell=True)
        if ok != 0:
            return False

        # TODO(gene.ge): how to save the default gateway in xorpplus mode
        if mode == cls.mode_ovs:
            cls.__pica_mode_ovs_set_configfile(None, gw)
        elif mode == cls.mode_xorpplus:
            cmd = "%s sync" % cls.pica_xorpplus_cli
            ok = subprocess.call(cmd, shell=True)
            if ok != 0:
                return False
        return True

    @classmethod
    def pica_setup_inband_ip(cls, ip):
        # TODO(gene.ge)
        pass

    @classmethod
    def pica_get_provision_script_path(cls):
        return cls.pica_provision_script_download_path

    @classmethod
    def pica_upgrade_os_with_targz(cls, os_file):
        cmd = "%s %s" % (cls.pica_upgrade_bin, os_file)
        return subprocess.call(cmd, shell=True)

    @classmethod
    def pica_upgrade_ovs_with_deb(cls, ovs_file):
        cmd = "dpkg -i %s" % ovs_file
        return subprocess.call(cmd, shell=True)

    @classmethod
    def __pica_change_ovsdb_server_ptcp_remote(cls, new_remote_ip):
        cmd = "/ovs/bin/ovs-appctl -t ovsdb-server  ovsdb-server/list-remotes | grep ptcp"
        if subprocess.call(cmd, shell=True,
                           stdout=open('/dev/null', 'w'),
                           stderr=subprocess.STDOUT) != 0:
            return
        old = subprocess.check_output(cmd, shell=True)
        if old.find("ptcp") != -1:
            cmd = "/ovs/bin/ovs-appctl -t ovsdb-server  ovsdb-server/remove-remote %s" % old
            subprocess.call(cmd, shell=True)
            (ip_addr, mask) = cidr_to_ipmaskstr(new_remote_ip)
            old_port = old[:old.rfind(':')+1]
            cmd = ("/ovs/bin/ovs-appctl -t ovsdb-server  "
                   "ovsdb-server/add-remote %s%s") % (old_port,ip_addr)
            subprocess.call(cmd, shell=True)


class InbandFlow(object):
    @staticmethod
    def call_cmd(cmd, verbose):
        if verbose == True:
            return call_with_command_line(cmd)
        else:
            return call_ignore_error_msg(cmd)

    @staticmethod
    def setup_flows_common(verbose):
        inband_db_file = "/ovs/inband.conf.db"
        inband_db_schema_file = "/ovs/share/openvswitch/inband.ovsschema"
        inband_br = "brib"

        if os.path.exists(inband_db_schema_file) == False:
            if verbose == True:
                print "%s does't exist." % inband_db_schema_file
            return False
        # create inband db
        if os.path.exists(inband_db_file) == False:
            cmd = "/ovs/bin/ovsdb-tool create %s %s" % \
              (inband_db_file, inband_db_schema_file)
            if InbandFlow().call_cmd(cmd, verbose) != 0:
                return False

        # del inband db firstly, then add db, to setup a clean environment
        cmd = ("/ovs/bin/ovs-appctl -t "
               "ovsdb-server ovsdb-server/remove-db Inband_Bridge")
        InbandFlow().call_cmd(cmd, verbose)   # do not check result
        # add inband db
        cmd = "/ovs/bin/ovs-appctl -t ovsdb-server ovsdb-server/add-db %s" % \
          inband_db_file
        if InbandFlow().call_cmd(cmd, verbose) != 0:
            return False

        # enable inband control
        cmd = "/ovs/bin/ovs-appctl inband/enable true"
        if InbandFlow().call_cmd(cmd, verbose) != 0:
            return False

        # del bridge firstly, then add-br, to setup a clean environment
        cmd = "/ovs/bin/ovs-ibctl del-br %s" % inband_br
        InbandFlow().call_cmd(cmd, verbose)   # do not check result
        cmd = ("/ovs/bin/ovs-ibctl add-br %s -- "
               "set bridge %s datapath_type=pica8 fail_mode=secure") % \
               (inband_br, inband_br)
        if InbandFlow().call_cmd(cmd, verbose) != 0:
            return False

        return True

    @staticmethod
    def setup_flows(inband_port,
                    inband_port_speed,
                    inband_local_ip,
                    inband_loopback_eth0,
                    inband_eth0_loopback_port,
                    inband_ctl_has_vlan,
                    inband_vlan,
                    verbose):
        if InbandFlow().setup_flows_common(verbose) == False:
            return False
        inband_br = "brib"
        inband_vport_name = "inband1"
        (ip_addr, mask) = cidr_to_ipmaskstr(inband_local_ip)
        # create virtual inband port
        cmd = ("/ovs/bin/ovs-ibctl add-port %s %s "
               "vlan_mode=trunk tag=1 trunks=%s -- "
               "set Interface inband1 type=pica8_inband "
               "options:egress_port=%s ") % \
               (inband_br, inband_vport_name, inband_vlan, inband_port)

        if inband_port_speed != "auto":
            subcmd  = "options:link_speed=%s " % inband_port_speed
            cmd += subcmd
        if inband_ctl_has_vlan:
            subcmd = "options:vlan=%s " % inband_vlan
            cmd += subcmd
        if InbandFlow().call_cmd(cmd, verbose) != 0:
            return False

        # create loopback port
        if inband_loopback_eth0 and inband_ctl_has_vlan:
            cmd = ("/ovs/bin/ovs-ibctl add-port %s %s vlan_mode=access "
                   "tag=1 -- set Interface %s type=pica8") % \
                  (inband_br, inband_eth0_loopback_port, \
                   inband_eth0_loopback_port)
            if InbandFlow().call_cmd(cmd, verbose) != 0:
                return False

        # set local ip, virtual inband port, etc..
        cmd = ("/ovs/bin/ovs-ibctl set bridge %s "
               "other_config:inband-local-ip=%s "
               "other_config:inband-vport=%s "
               "other_config:inband-local-port=%s ") % \
               (inband_br, ip_addr, inband_vport_name,
                inband_eth0_loopback_port)
        if inband_ctl_has_vlan:
            subcmd = "other_config:inband-vlan=%s " % inband_vlan
            cmd += subcmd
        if InbandFlow().call_cmd(cmd, verbose) != 0:
            return False

        return True
